# Mini Project Showcase Portal

**Discover. Showcase. Innovate.**

A college hackathon web application that gives students a single, moderated place to submit their mini projects, lets faculty review and approve them, and turns every approved project into a public showcase entry with search, filtering and live analytics.

---

## Problem Statement

Student project information in colleges is typically scattered and hard to act on:

- **Scattered project info** - project titles, GitHub links, screenshots and team details live in WhatsApp groups, email threads and personal drives, so past work cannot be found when it is needed.
- **No approval mechanism** - there is no structured way for faculty to verify a submission before it is displayed in the name of the department.
- **No discovery** - juniors cannot search what seniors have already built by technology, category or batch, which leads to repeated or duplicated ideas.
- **No central showcase** - the department has no single public page it can point visitors, recruiters and accreditation teams to.

The Mini Project Showcase Portal solves all four problems with one moderated, searchable, database-backed portal.

---

## Features

### Public Visitor (no login required)
- Home page with portal overview and live counts (approved projects, categories, how it works).
- Explore page listing **only faculty-approved** projects.
- Keyword search across title, description and student name; filters by technology, category and batch; sorting (newest, oldest, title).
- Project detail view with screenshot, team members, technologies, GitHub link and submission metadata.
- Category pages showing approved projects per category (`/api/projects/category/:category`).

### Student
- Register and login (JWT session, persisted client-side, 7-day expiry).
- Submit a project via a multipart form: title, description, technologies, team members, GitHub link, category, batch and a **mandatory screenshot** (JPG/PNG/WebP, max 5 MB).
- New submissions are stored with status **Pending**; students can never set their own approval status.
- Personal dashboard with stat cards (Total / Pending / Approved / Rejected) and the list of their own projects in every status.
- Edit or delete a project **only while it is still Pending** (replacing the screenshot removes the old file).
- See the review outcome on the dashboard: approved projects go public, rejected ones stay private to the owner and faculty.

### Faculty
- Login with a faculty account and land on the faculty dashboard.
- **Review queue** of all Pending submissions (oldest first) with full project details and screenshot.
- Review dialog with **Approve** and **Reject** actions (reject requires confirmation); `reviewedAt` is stamped on every decision.
- Browse all projects with status / category / batch filters and the same search as Explore.
- **Category management**: create categories, rename them with safe reassignment of existing projects, and delete is blocked while any project still uses the category.
- **Analytics** computed live from the database: total / pending / approved / rejected counts plus Projects-by-Category and Projects-by-Batch bar charts.

---

## Technology Stack

This build was developed inside a Next.js sandbox, so an equivalent modern stack was used. **Every functional requirement of the original Express + MongoDB + Multer + HTML/CSS/JS spec is implemented end-to-end** - the mapping below shows exactly what replaced what.

| Spec (hackathon) | This build | Notes |
|---|---|---|
| Express routes/controllers | Next.js 16 App Router Route Handlers (`src/app/api/**/route.ts`) | Same REST shape and paths: `/api/auth/register`, `/api/projects/add`, `/api/projects/status/:id`, etc. |
| MongoDB + Mongoose | SQLite + Prisma ORM 6 (`prisma/schema.prisma`) | Three collections map 1:1 to the three models (see mapping note below). |
| Multer file uploads | Multipart `FormData` parsed in API routes + `src/lib/upload.ts` | Type/size validation (JPG/PNG/WebP, 5 MB), safe random filenames, served via `/api/uploads/:name`. |
| JWT auth | `jose` (HS256, 7-day expiry, `Authorization: Bearer` header) + `bcryptjs` password hashing + role checks (`src/lib/auth.ts`) | Exactly as the spec required. |
| HTML/CSS/JS frontend | React 19 single-page app with hash routing, Tailwind CSS 4 + shadcn/ui, Zustand session store | All views live under `/` (`#/explore`, `#/dashboard`, ...); navy/teal academic design. |
| JavaScript | TypeScript 5 | Shared validation constants used by both API and forms. |

### MongoDB / Mongoose to Prisma / SQLite mapping

If the project is ported to Express + MongoDB, the data model transfers 1:1:

| MongoDB / Mongoose | Prisma / SQLite (this build) |
|---|---|
| `users` collection | `User` model |
| `projects` collection | `Project` model |
| `categories` collection | `Category` model |
| `_id: ObjectId` | `id: String @id @default(cuid())` |
| Mongoose `Schema` + validators | Prisma model fields + shared validators in `src/lib/validate.ts` / `project-form.ts` |
| `Model.findOne()`, `find()`, `create()`, `findByIdAndUpdate()`, `deleteOne()` | `db.user.findUnique()`, `db.project.findMany()`, `db.project.create()`, `db.project.update()`, `db.project.delete()` |
| `.populate('studentId')` | `include: { student: { select: ... } }` |
| `{ $regex: q, $options: 'i' }` text search | `contains: q` filters |
| Referenced `studentId` field | Foreign key `studentId` with `onDelete: Cascade` |

The REST route paths, request/response payloads, roles and business rules are identical in both stacks, so porting consists mainly of swapping Prisma calls for Mongoose calls inside the same controller logic.

---

## Getting Started

### Prerequisites
- Node.js 18+ (or Bun) and npm
- No external database server needed - SQLite is a local file

### Install
```bash
npm install   # or: bun install
```

### Configure environment
Copy the example file and adjust the absolute path of the database if needed:

```bash
cp .env.example .env
```

`.env.example` contains:
```env
# Database connection (SQLite file used by Prisma in this build)
DATABASE_URL=file:/home/z/my-project/db/custom.db

# Secret used to sign JWT tokens - replace with a long random string in production
JWT_SECRET=replace_with_a_long_random_secret
```

### Create the database and load demo data
```bash
npm run db:push   # creates/updates the SQLite schema from prisma/schema.prisma
npm run seed      # resets all Users, Projects and Categories and inserts demo data
```

### Run
```bash
npm run dev       # next dev -p 3000
```
Open **http://localhost:3000** in your browser.

Lint check (optional):
```bash
npm run lint
```

---

## Demo Credentials

| Role | Name | Email | Password |
|---|---|---|---|
| Faculty | Dr. Meera Krishnan | `faculty@college.edu` | `Faculty@123` |
| Student | Aarav Sharma | `aarav@college.edu` | `Student@123` |
| Student | Priya Nair | `priya@college.edu` | `Student@123` |
| Student | Rohan Gupta | `rohan@college.edu` | `Student@123` |

The seed data includes 5 categories (Web Development, Mobile Applications, Artificial Intelligence, IoT, Other) and 6 sample projects across categories, batches and all three statuses (4 Approved, 1 Pending, 1 Rejected), e.g. *AI-Powered Cattle Breed Recognition*, *Student Performance Analytics*, *IoT Smart Irrigation System*, *Credit Card Fraud Detection*, *Smart Attendance System*, *Library Seat Booking System*.

> **Note:** `npm run seed` **resets** all Users, Projects and Categories before inserting the demo data. Run it any time you want a clean demo state.

---

## API Endpoints

All endpoints return JSON. Authenticated requests send `Authorization: Bearer <token>`.

| Method | Route | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create student/faculty account (bcrypt hash), returns JWT + user |
| POST | `/api/auth/login` | Public | Verify credentials, returns JWT + user |
| GET | `/api/auth/me` | Authenticated | Return current user from the JWT (session validation) |
| GET | `/api/projects` | Public / Student / Faculty | Public: approved projects only. `?scope=mine`: student's own projects. Faculty token: all projects with `status` filter. Supports `q`, `tech`, `category`, `batch`, `sort`, `limit` |
| POST | `/api/projects/add` | Student | Multipart submission with screenshot; stored with status `Pending` |
| GET | `/api/projects/mine` | Student | The logged-in student's projects (all statuses) |
| GET | `/api/projects/pending` | Faculty | All Pending projects, oldest first |
| GET | `/api/projects/stats` | Faculty | Dashboard analytics: status counts + projects grouped by category and batch |
| GET | `/api/projects/category/:category` | Public | Approved projects in a category |
| PUT | `/api/projects/status/:id` | Faculty | Approve or reject a project (`Approved` / `Rejected`), stamps `reviewedAt` |
| GET | `/api/projects/:id` | Public / Owner / Faculty | Approved projects are public; Pending/Rejected visible only to the owner or faculty |
| PUT | `/api/projects/:id` | Student (owner, Pending only) | Edit project details, optionally replace screenshot |
| DELETE | `/api/projects/:id` | Student (owner, Pending only) | Delete project and its uploaded screenshot |
| GET | `/api/categories` | Public | Categories with total and approved project counts |
| POST | `/api/categories` | Faculty | Create a category (unique name) |
| PUT | `/api/categories/:id` | Faculty | Rename a category; existing projects are safely re-assigned |
| DELETE | `/api/categories/:id` | Faculty | Delete a category (blocked with 409 while projects use it) |
| GET | `/api/uploads/:name` | Public | Serve an uploaded screenshot from the `uploads/` folder |

---

## Database Schema

Defined in `prisma/schema.prisma` (SQLite). The three models correspond directly to the three MongoDB collections in the original spec (see the mapping table above).

### User - students and faculty
| Field | Type | Notes |
|---|---|---|
| `id` | String (cuid) | Primary key |
| `name` | String | Full name |
| `email` | String | Unique |
| `password` | String | bcrypt hash - never returned by APIs |
| `role` | String | `"student"` (default) or `"faculty"` |
| `createdAt` / `updatedAt` | DateTime | Auto-managed |

Relationship: `projects Project[]` - one user owns many projects.

### Project - a submitted mini project
| Field | Type | Notes |
|---|---|---|
| `id` | String (cuid) | Primary key |
| `title` | String | Min 3 chars (validated) |
| `description` | String | Min 20 chars (validated) |
| `technologies` | String | Comma-separated list, exposed as an array by the API |
| `teamMembers` | String | Comma-separated list, exposed as an array by the API |
| `githubLink` | String | Must match `https://github.com/user/repo` |
| `screenshotPath` | String? | Public path `/api/uploads/:name` |
| `category` | String | Must match an existing `Category.name` at submission time |
| `batch` | String | One of `2022-2026`, `2023-2027`, `2024-2028`, `2025-2029` |
| `studentId` | String | FK to `User.id`, `onDelete: Cascade` |
| `status` | String | `"Pending"` (default) / `"Approved"` / `"Rejected"` |
| `reviewedAt` | DateTime? | Set by faculty on approve/reject |
| `createdAt` / `updatedAt` | DateTime | Auto-managed |

Indexes: `@@index([status])`, `@@index([studentId])`, `@@index([category])`, `@@index([batch])` - one per query path used by the list/filter/stats endpoints.

Relationship: `student User` - each project belongs to exactly one student.

### Category - faculty-managed project categories
| Field | Type | Notes |
|---|---|---|
| `id` | String (cuid) | Primary key |
| `name` | String | Unique, min 2 chars |
| `createdAt` / `updatedAt` | DateTime | Auto-managed |

Projects reference categories by name; renaming a category re-assigns all matching projects in one `updateMany`, and deletion is refused while any project still uses it.

---

## Approval Workflow

The full lifecycle requested by the hackathon spec, as implemented:

1. **Registration** - a student creates an account (`POST /api/auth/register`); the password is hashed with bcrypt and a JWT is issued.
2. **Submission** - the student logs in and submits the project form with a screenshot (`POST /api/projects/add`).
3. **Database storage with Pending** - the record is stored with status `Pending`; the client cannot influence the status.
4. **Faculty review** - faculty logs in, opens the review queue (`GET /api/projects/pending`) and the review dialog for a submission.
5. **Approve or reject** - faculty chooses Approve or Reject (reject requires confirmation) (`PUT /api/projects/status/:id`).
6. **Status update** - the project's `status` and `reviewedAt` are updated in the database.
7. **Public visibility** - approved projects immediately appear on Home, Explore and category pages; rejected projects stay hidden (the detail endpoint returns 404 to non-owners).
8. **Student dashboard reflects it** - the student's dashboard and stat cards show the new status; a Pending project can still be edited or deleted by its owner, reviewed ones cannot.

---

## Security & Validation

- **Password hashing** - bcrypt (`bcryptjs`, cost 10); password hashes are never included in any API response.
- **JWT authentication** - HS256 tokens signed with `JWT_SECRET`, 7-day expiry, sent as `Authorization: Bearer`; invalid/expired tokens are rejected and the client clears the stale session with a "session expired" toast.
- **Role middleware** - every protected route checks the token's role; only faculty can review, manage categories and view analytics; only students can submit and edit their own projects.
- **Ownership checks** - project edit/delete verify `studentId === token.id` before touching data.
- **Pending-only edits** - edit and delete are refused once a project has been reviewed.
- **Visibility rules** - `GET /api/projects/:id` returns 404 (not 403) for non-public projects so their existence is never leaked; public project lists always filter `status = "Approved"`.
- **Upload restrictions** - MIME type whitelist (JPG/PNG/WebP), 5 MB size limit, empty-file rejection; files are stored under system-generated names (`timestamp-randomhex.ext`) so user input never forms a file path.
- **Safe file serving** - `/api/uploads/:name` validates filenames with a strict regex and blocks path traversal.
- **Input validation** - server-side length clamping and control-character stripping on all text fields, email format check, GitHub URL format check, batch whitelist, category existence check, unique email and unique category name.
- **No client-trusted fields** - approval status, role normalization and ownership are always decided server-side.

---

## Project Structure

```
my-project/
├── prisma/
│   └── schema.prisma            # User, Project, Category models (SQLite)
├── scripts/
│   └── seed.ts                  # Demo data reset + insertion (run: npm run seed)
├── src/
│   ├── app/
│   │   ├── api/                 # Backend (Route Handlers = Express equivalent)
│   │   │   ├── auth/register/route.ts
│   │   │   ├── auth/login/route.ts
│   │   │   ├── auth/me/route.ts
│   │   │   ├── projects/route.ts                  # GET list (public/mine/faculty)
│   │   │   ├── projects/add/route.ts              # POST submit (multipart)
│   │   │   ├── projects/mine/route.ts
│   │   │   ├── projects/pending/route.ts
│   │   │   ├── projects/stats/route.ts
│   │   │   ├── projects/category/[category]/route.ts
│   │   │   ├── projects/status/[id]/route.ts      # PUT approve/reject
│   │   │   ├── projects/[id]/route.ts             # GET / PUT / DELETE
│   │   │   ├── categories/route.ts                # GET / POST
│   │   │   ├── categories/[id]/route.ts           # PUT rename / DELETE
│   │   │   ├── uploads/[name]/route.ts            # Screenshot file server
│   │   │   └── route.ts
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   └── page.tsx             # SPA shell: hash router + route guards
│   ├── components/portal/       # All views and shared UI
│   │   ├── HomeView.tsx         # Hero, live stats, approved highlights
│   │   ├── ExploreView.tsx      # Search + filters over approved projects
│   │   ├── ProjectDetailsView.tsx
│   │   ├── ProjectCard.tsx
│   │   ├── ProjectForm.tsx      # Add / edit (multipart with screenshot)
│   │   ├── StudentDashboard.tsx # Stat cards + own projects
│   │   ├── FacultyDashboard.tsx # Review / Categories / Analytics tabs
│   │   ├── AuthView.tsx         # Login / register
│   │   ├── Header.tsx, Footer.tsx, ui-bits.tsx, format.ts
│   └── lib/                     # Shared server/client utilities
│       ├── auth.ts              # JWT sign/verify + Bearer parsing (role middleware)
│       ├── validate.ts          # Email/GitHub/text validators, status whitelist
│       ├── upload.ts            # Multer equivalent: type/size checks, safe names
│       ├── project-form.ts      # Shared add/edit form parser + validation
│       ├── serialize.ts         # Prisma record -> safe API response
│       ├── db.ts                # Prisma client singleton
│       ├── http.ts              # Consistent JSON responses
│       ├── router.ts            # Hash router hook
│       ├── store.ts             # Zustand persisted auth session
│       ├── api-client.ts, constants.ts, types.ts, utils.ts
├── uploads/                     # Uploaded screenshots (served via /api/uploads/:name)
├── db/                          # SQLite database file (per DATABASE_URL)
├── docs/
│   ├── PRESENTATION_OUTLINE.md
│   └── DEMO_VIDEO_SCRIPT.md
├── .env.example
└── package.json
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Database errors (missing file, table does not exist) | Re-run `npm run db:push` to create/update the SQLite schema, then `npm run seed` if you want the demo data back. |
| Want a clean demo state before presenting | Run `npm run seed` - it deletes all Users, Projects and Categories and re-inserts the demo data. |
| Port 3000 already in use | Stop the other process, or start on a different port, e.g. `npx next dev -p 3001`. |
| "Your session has expired" toast after login | The stored JWT expired or `JWT_SECRET` changed - log in again; tokens are valid for 7 days. |
| Upload rejected | Only JPG/PNG/WebP under 5 MB are accepted; empty files are rejected. |
| Cannot edit/delete a project | Only your own projects can be edited, and only while they are still Pending. |
| Category cannot be deleted | Categories still used by projects are protected - rename it or re-assign those projects first. |

---

## Hackathon Deliverables

- Presentation slide deck outline: [`docs/PRESENTATION_OUTLINE.md`](docs/PRESENTATION_OUTLINE.md)
- Demo video recording script: [`docs/DEMO_VIDEO_SCRIPT.md`](docs/DEMO_VIDEO_SCRIPT.md)
