import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'
import { serializeProject } from '@/lib/serialize'
import { isProjectStatus } from '@/lib/validate'

/**
 * PUT /api/projects/status/:id - faculty approves or rejects a project.
 * Students are never allowed to call this.
 */
export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to continue.' }, 401)
    if (user.role !== 'faculty') {
      return json({ error: 'Only faculty members can approve or reject projects.' }, 403)
    }

    const { id } = await params
    const body = (await req.json().catch(() => null)) as { status?: unknown } | null
    if (!body || !isProjectStatus(body.status) || body.status === 'Pending') {
      return json({ error: 'Status must be either "Approved" or "Rejected".' }, 400)
    }

    const existing = await db.project.findUnique({ where: { id } })
    if (!existing) return json({ error: 'Project not found.' }, 404)

    const updated = await db.project.update({
      where: { id },
      data: { status: body.status, reviewedAt: new Date() },
      include: { student: { select: { id: true, name: true, email: true } } },
    })

    return json({
      message:
        body.status === 'Approved'
          ? `"${updated.title}" has been approved and is now visible on the public showcase.`
          : `"${updated.title}" has been rejected and stays hidden from the public showcase.`,
      project: serializeProject(updated),
    })
  } catch {
    return json({ error: 'Could not update the project status.' }, 500)
  }
}
