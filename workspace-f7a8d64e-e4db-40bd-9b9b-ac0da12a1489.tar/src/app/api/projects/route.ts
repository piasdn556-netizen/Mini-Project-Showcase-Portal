import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'
import { serializeProject } from '@/lib/serialize'
import { isProjectStatus } from '@/lib/validate'
import { Prisma } from '@prisma/client'

/**
 * GET /api/projects
 * - Default (no auth or any auth) -> PUBLIC showcase list: APPROVED projects only
 * - scope=mine                    -> the logged-in student's own projects (all statuses)
 * - scope=all + faculty token     -> every project, with optional status/category/batch filters
 *
 * Filters: q (title/description/student name), tech, category, batch, sort, limit
 */
export async function GET(req: Request) {
  try {
    const user = await getAuthUser(req)
    const { searchParams } = new URL(req.url)

    const scope = searchParams.get('scope') ?? ''
    const q = (searchParams.get('q') ?? '').trim()
    const tech = (searchParams.get('tech') ?? '').trim()
    const category = searchParams.get('category') ?? ''
    const batch = searchParams.get('batch') ?? ''
    const status = searchParams.get('status') ?? ''
    const sort = searchParams.get('sort') ?? 'newest'
    const limit = Number(searchParams.get('limit') ?? 0)

    if (scope === 'mine') {
      if (!user) return json({ error: 'Please login to view your projects.' }, 401)
      if (user.role !== 'student') {
        return json({ error: 'Only students have personal projects.' }, 403)
      }
      const projects = await db.project.findMany({
        where: { studentId: user.id },
        include: { student: { select: { id: true, name: true, email: true } } },
        orderBy: { createdAt: 'desc' },
      })
      return json({ projects: projects.map(serializeProject), total: projects.length })
    }

    // Faculty-only full listing for the review dashboard; everything else is
    // the public showcase and must contain Approved projects exclusively.
    const facultyAll = scope === 'all' && user?.role === 'faculty'
    const where: Prisma.ProjectWhereInput = {}

    if (facultyAll) {
      if (isProjectStatus(status)) where.status = status
    } else {
      where.status = 'Approved'
    }

    if (q) {
      where.OR = [
        { title: { contains: q } },
        { description: { contains: q } },
        { student: { name: { contains: q } } },
      ]
    }
    if (tech) where.technologies = { contains: tech }
    if (category) where.category = category
    if (batch) where.batch = batch

    const orderBy: Prisma.ProjectOrderByWithRelationInput =
      sort === 'oldest' ? { createdAt: 'asc' } : sort === 'title' ? { title: 'asc' } : { createdAt: 'desc' }

    const total = await db.project.count({ where })
    const projects = await db.project.findMany({
      where,
      include: { student: { select: { id: true, name: true, email: true } } },
      orderBy,
      ...(Number.isFinite(limit) && limit > 0 ? { take: Math.min(limit, 50) } : {}),
    })

    return json({ projects: projects.map(serializeProject), total })
  } catch {
    return json({ error: 'Unable to load projects right now. Please try again.' }, 500)
  }
}
