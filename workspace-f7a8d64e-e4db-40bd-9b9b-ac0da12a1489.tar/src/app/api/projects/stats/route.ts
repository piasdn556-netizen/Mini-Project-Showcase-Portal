import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'

/** GET /api/projects/stats - faculty dashboard analytics from live records. */
export async function GET(req: Request) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to continue.' }, 401)
    if (user.role !== 'faculty') {
      return json({ error: 'Only faculty members can view dashboard analytics.' }, 403)
    }

    const [total, pending, approved, rejected, byCategoryRaw, byBatchRaw] = await Promise.all([
      db.project.count(),
      db.project.count({ where: { status: 'Pending' } }),
      db.project.count({ where: { status: 'Approved' } }),
      db.project.count({ where: { status: 'Rejected' } }),
      db.project.groupBy({ by: ['category'], _count: { _all: true } }),
      db.project.groupBy({ by: ['batch'], _count: { _all: true } }),
    ])

    const byCategory = byCategoryRaw
      .map((g) => ({ name: g.category, count: g._count._all }))
      .sort((a, b) => b.count - a.count)
    const byBatch = byBatchRaw
      .map((g) => ({ name: g.batch, count: g._count._all }))
      .sort((a, b) => a.name.localeCompare(b.name))

    return json({ total, pending, approved, rejected, byCategory, byBatch })
  } catch {
    return json({ error: 'Unable to compute dashboard statistics.' }, 500)
  }
}
