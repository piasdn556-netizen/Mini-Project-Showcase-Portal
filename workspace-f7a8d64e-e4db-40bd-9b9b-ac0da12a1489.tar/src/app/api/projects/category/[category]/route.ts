import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { serializeProject } from '@/lib/serialize'

/** GET /api/projects/category/:category - public list of approved projects in a category. */
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ category: string }> }
) {
  try {
    const { category } = await params
    const decoded = decodeURIComponent(category).trim()
    if (!decoded) return json({ error: 'Category is required.' }, 400)

    const projects = await db.project.findMany({
      where: { status: 'Approved', category: decoded },
      include: { student: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: 'desc' },
    })
    return json({ projects: projects.map(serializeProject), total: projects.length })
  } catch {
    return json({ error: 'Unable to load projects for this category.' }, 500)
  }
}
