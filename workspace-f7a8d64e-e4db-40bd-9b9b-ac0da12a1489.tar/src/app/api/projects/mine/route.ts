import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'
import { serializeProject } from '@/lib/serialize'

/** GET /api/projects/mine - the logged-in student's own projects. */
export async function GET(req: Request) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to view your projects.' }, 401)
    if (user.role !== 'student') {
      return json({ error: 'Only students have personal projects.' }, 403)
    }

    const projects = await db.project.findMany({
      where: { studentId: user.id },
      include: { student: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: 'desc' },
    })
    return json({ projects: projects.map(serializeProject), total: projects.length })
  } catch {
    return json({ error: 'Unable to load your projects right now.' }, 500)
  }
}
