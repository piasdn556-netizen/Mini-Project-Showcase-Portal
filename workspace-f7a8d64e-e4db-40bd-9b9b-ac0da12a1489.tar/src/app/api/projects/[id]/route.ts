import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'
import { parseProjectForm } from '@/lib/project-form'
import { saveUpload, deleteUpload } from '@/lib/upload'
import { serializeProject } from '@/lib/serialize'

/**
 * GET /api/projects/:id
 * - Approved projects: public.
 * - Pending / Rejected: only the owner (student) or faculty can view.
 */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const project = await db.project.findUnique({
      where: { id },
      include: { student: { select: { id: true, name: true, email: true } } },
    })
    if (!project) return json({ error: 'Project not found.' }, 404)

    if (project.status !== 'Approved') {
      const user = await getAuthUser(req)
      const isOwner = user?.role === 'student' && user.id === project.studentId
      const isFaculty = user?.role === 'faculty'
      if (!isOwner && !isFaculty) {
        // Do not leak the existence of non-public projects.
        return json({ error: 'Project not found or not publicly visible.' }, 404)
      }
    }

    return json({ project: serializeProject(project) })
  } catch {
    return json({ error: 'Unable to load this project.' }, 500)
  }
}

/** PUT /api/projects/:id - owner edits a project that is still Pending. */
export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to edit projects.' }, 401)
    if (user.role !== 'student') {
      return json({ error: 'Only students can edit projects.' }, 403)
    }

    const { id } = await params
    const existing = await db.project.findUnique({ where: { id } })
    if (!existing) return json({ error: 'Project not found.' }, 404)
    if (existing.studentId !== user.id) {
      return json({ error: 'You can only edit your own projects.' }, 403)
    }
    if (existing.status !== 'Pending') {
      return json({ error: 'This project has already been reviewed. Only pending projects can be edited.' }, 403)
    }

    const form = await req.formData().catch(() => null)
    if (!form) return json({ error: 'Invalid form submission.' }, 400)

    const parsed = await parseProjectForm(form)
    if (!parsed.ok) return json({ error: parsed.error }, parsed.status)

    let screenshotPath = existing.screenshotPath
    if (parsed.screenshotFile) {
      const saved = await saveUpload(parsed.screenshotFile)
      if (!saved.ok) return json({ error: saved.error }, saved.status)
      await deleteUpload(existing.screenshotPath)
      screenshotPath = saved.path
    }

    const updated = await db.project.update({
      where: { id },
      data: { ...parsed.data, screenshotPath },
      include: { student: { select: { id: true, name: true, email: true } } },
    })

    return json({ message: 'Project updated successfully.', project: serializeProject(updated) })
  } catch {
    return json({ error: 'Could not update the project. Please try again.' }, 500)
  }
}

/** DELETE /api/projects/:id - owner deletes a project that is still Pending. */
export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to delete projects.' }, 401)
    if (user.role !== 'student') {
      return json({ error: 'Only students can delete projects.' }, 403)
    }

    const { id } = await params
    const existing = await db.project.findUnique({ where: { id } })
    if (!existing) return json({ error: 'Project not found.' }, 404)
    if (existing.studentId !== user.id) {
      return json({ error: 'You can only delete your own projects.' }, 403)
    }
    if (existing.status !== 'Pending') {
      return json({ error: 'This project has already been reviewed. Only pending projects can be deleted.' }, 403)
    }

    await deleteUpload(existing.screenshotPath)
    await db.project.delete({ where: { id } })

    return json({ message: `"${existing.title}" was deleted successfully.` })
  } catch {
    return json({ error: 'Could not delete the project. Please try again.' }, 500)
  }
}
