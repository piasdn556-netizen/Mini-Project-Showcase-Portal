import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'
import { parseProjectForm } from '@/lib/project-form'
import { saveUpload } from '@/lib/upload'
import { serializeProject } from '@/lib/serialize'

/** POST /api/projects/add - student submits a new project (multipart form + screenshot). */
export async function POST(req: Request) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to submit a project.' }, 401)
    if (user.role !== 'student') {
      return json({ error: 'Only students can submit projects.' }, 403)
    }

    const form = await req.formData().catch(() => null)
    if (!form) return json({ error: 'Invalid form submission.' }, 400)

    const parsed = await parseProjectForm(form)
    if (!parsed.ok) return json({ error: parsed.error }, parsed.status)

    if (!parsed.screenshotFile) {
      return json({ error: 'Please upload a project screenshot or logo (JPG, PNG or WebP).' }, 400)
    }
    const saved = await saveUpload(parsed.screenshotFile)
    if (!saved.ok) return json({ error: saved.error }, saved.status)

    const project = await db.project.create({
      data: {
        ...parsed.data,
        screenshotPath: saved.path,
        studentId: user.id,
        status: 'Pending', // students can never set their own approval status
      },
      include: { student: { select: { id: true, name: true, email: true } } },
    })

    return json(
      {
        message: 'Project submitted successfully! It is now pending faculty review.',
        project: serializeProject(project),
      },
      201
    )
  } catch {
    return json({ error: 'Could not submit the project. Please try again.' }, 500)
  }
}
