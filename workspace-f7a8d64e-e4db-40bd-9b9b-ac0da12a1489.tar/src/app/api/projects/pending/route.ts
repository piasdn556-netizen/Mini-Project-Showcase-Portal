import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'
import { serializeProject } from '@/lib/serialize'

/** GET /api/projects/pending - faculty-only list of projects awaiting review. */
export async function GET(req: Request) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to continue.' }, 401)
    if (user.role !== 'faculty') {
      return json({ error: 'Only faculty members can view pending submissions.' }, 403)
    }

    const projects = await db.project.findMany({
      where: { status: 'Pending' },
      include: { student: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: 'asc' }, // oldest submissions first
    })
    return json({ projects: projects.map(serializeProject), total: projects.length })
  } catch {
    return json({ error: 'Unable to load pending projects.' }, 500)
  }
}
