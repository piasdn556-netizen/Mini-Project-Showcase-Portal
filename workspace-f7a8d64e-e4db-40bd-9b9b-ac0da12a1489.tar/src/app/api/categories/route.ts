import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'
import { cleanText } from '@/lib/validate'

/** GET /api/categories - public list with project counts (faculty uses projectCount). */
export async function GET() {
  try {
    const [categories, totalRaw, approvedRaw] = await Promise.all([
      db.category.findMany({ orderBy: { name: 'asc' } }),
      db.project.groupBy({ by: ['category'], _count: { _all: true } }),
      db.project.groupBy({
        by: ['category'],
        where: { status: 'Approved' },
        _count: { _all: true },
      }),
    ])

    const totals = new Map(totalRaw.map((g) => [g.category, g._count._all]))
    const approved = new Map(approvedRaw.map((g) => [g.category, g._count._all]))

    return json({
      categories: categories.map((c) => ({
        id: c.id,
        name: c.name,
        projectCount: totals.get(c.name) ?? 0,
        approvedCount: approved.get(c.name) ?? 0,
      })),
    })
  } catch {
    return json({ error: 'Unable to load categories.' }, 500)
  }
}

/** POST /api/categories - faculty creates a new category. */
export async function POST(req: Request) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to continue.' }, 401)
    if (user.role !== 'faculty') {
      return json({ error: 'Only faculty members can manage categories.' }, 403)
    }

    const body = (await req.json().catch(() => null)) as { name?: unknown } | null
    const name = cleanText(body?.name, 40)
    if (name.length < 2) {
      return json({ error: 'Category name must be at least 2 characters long.' }, 400)
    }

    const all = await db.category.findMany()
    if (all.some((c) => c.name.toLowerCase() === name.toLowerCase())) {
      return json({ error: `Category "${name}" already exists.` }, 409)
    }

    const category = await db.category.create({ data: { name } })
    return json({ message: `Category "${name}" created successfully.`, category }, 201)
  } catch {
    return json({ error: 'Could not create the category.' }, 500)
  }
}
