import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'
import { cleanText } from '@/lib/validate'

/** PUT /api/categories/:id - faculty renames a category (projects are safely re-assigned). */
export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to continue.' }, 401)
    if (user.role !== 'faculty') {
      return json({ error: 'Only faculty members can manage categories.' }, 403)
    }

    const { id } = await params
    const body = (await req.json().catch(() => null)) as { name?: unknown } | null
    const name = cleanText(body?.name, 40)
    if (name.length < 2) {
      return json({ error: 'Category name must be at least 2 characters long.' }, 400)
    }

    const category = await db.category.findUnique({ where: { id } })
    if (!category) return json({ error: 'Category not found.' }, 404)

    const all = await db.category.findMany()
    if (all.some((c) => c.id !== id && c.name.toLowerCase() === name.toLowerCase())) {
      return json({ error: `Category "${name}" already exists.` }, 409)
    }

    const oldName = category.name
    const updated = await db.category.update({ where: { id }, data: { name } })

    // Safe reassignment: keep existing projects pointing at the new name.
    const reassigned = await db.project.updateMany({
      where: { category: oldName },
      data: { category: name },
    })

    return json({
      message:
        reassigned.count > 0
          ? `Category renamed to "${name}". ${reassigned.count} project(s) were updated to the new name.`
          : `Category renamed to "${name}".`,
      category: updated,
    })
  } catch {
    return json({ error: 'Could not rename the category.' }, 500)
  }
}

/** DELETE /api/categories/:id - blocked while projects still use the category. */
export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getAuthUser(req)
    if (!user) return json({ error: 'Please login to continue.' }, 401)
    if (user.role !== 'faculty') {
      return json({ error: 'Only faculty members can manage categories.' }, 403)
    }

    const { id } = await params
    const category = await db.category.findUnique({ where: { id } })
    if (!category) return json({ error: 'Category not found.' }, 404)

    const inUse = await db.project.count({ where: { category: category.name } })
    if (inUse > 0) {
      return json(
        {
          error: `Cannot delete "${category.name}" because ${inUse} project(s) still use it. Rename or re-assign those projects first.`,
        },
        409
      )
    }

    await db.category.delete({ where: { id } })
    return json({ message: `Category "${category.name}" was deleted.` })
  } catch {
    return json({ error: 'Could not delete the category.' }, 500)
  }
}
