import { readFile } from 'fs/promises'
import path from 'path'
import { json } from '@/lib/http'

/**
 * GET /api/uploads/:name - serves uploaded screenshots from the uploads folder.
 * Filenames are system-generated; the strict regex prevents path traversal.
 */
const CONTENT_TYPES: Record<string, string> = {
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  png: 'image/png',
  webp: 'image/webp',
}

export async function GET(_req: Request, { params }: { params: Promise<{ name: string }> }) {
  const { name } = await params
  if (!/^[A-Za-z0-9._-]+$/.test(name) || name.includes('..')) {
    return json({ error: 'Invalid file name.' }, 400)
  }
  const ext = name.split('.').pop()?.toLowerCase() ?? ''
  const contentType = CONTENT_TYPES[ext]
  if (!contentType) return json({ error: 'Unsupported file type.' }, 400)

  try {
    const buffer = await readFile(path.join(process.cwd(), 'uploads', name))
    return new Response(new Uint8Array(buffer), {
      headers: {
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=31536000, immutable',
      },
    })
  } catch {
    return json({ error: 'File not found.' }, 404)
  }
}
