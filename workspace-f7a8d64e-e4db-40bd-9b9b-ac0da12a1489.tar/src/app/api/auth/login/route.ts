import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { signToken } from '@/lib/auth'
import { cleanText } from '@/lib/validate'
import { compare } from 'bcryptjs'

interface LoginBody {
  email?: unknown
  password?: unknown
}

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => null)) as LoginBody | null
    if (!body) return json({ error: 'Invalid request body.' }, 400)

    const email = cleanText(body.email, 120).toLowerCase()
    const password = typeof body.password === 'string' ? body.password : ''

    if (!email || !password) {
      return json({ error: 'Please enter both email and password.' }, 400)
    }

    const user = await db.user.findUnique({ where: { email } })
    if (!user) {
      return json({ error: 'Invalid email or password.' }, 401)
    }

    const passwordMatches = await compare(password, user.password)
    if (!passwordMatches) {
      return json({ error: 'Invalid email or password.' }, 401)
    }

    const token = await signToken({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role as 'student' | 'faculty',
    })

    return json({
      message: `Welcome back, ${user.name}!`,
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    })
  } catch {
    return json({ error: 'Login failed. Please try again.' }, 500)
  }
}
