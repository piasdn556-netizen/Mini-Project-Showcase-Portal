import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { signToken } from '@/lib/auth'
import { cleanText, isValidEmail } from '@/lib/validate'
import { hash } from 'bcryptjs'

interface RegisterBody {
  name?: unknown
  email?: unknown
  password?: unknown
  role?: unknown
}

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => null)) as RegisterBody | null
    if (!body) return json({ error: 'Invalid request body.' }, 400)

    const name = cleanText(body.name, 80)
    const email = cleanText(body.email, 120).toLowerCase()
    const password = typeof body.password === 'string' ? body.password : ''
    const role = body.role === 'faculty' ? 'faculty' : 'student'

    if (name.length < 2) {
      return json({ error: 'Please enter your full name (at least 2 characters).' }, 400)
    }
    if (!isValidEmail(email)) {
      return json({ error: 'Please enter a valid email address.' }, 400)
    }
    if (password.length < 6) {
      return json({ error: 'Password must be at least 6 characters long.' }, 400)
    }

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) {
      return json({ error: 'An account with this email already exists. Try logging in instead.' }, 409)
    }

    const passwordHash = await hash(password, 10)
    const user = await db.user.create({
      data: { name, email, password: passwordHash, role },
      select: { id: true, name: true, email: true, role: true },
    })

    const token = await signToken({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role as 'student' | 'faculty',
    })
    return json({ message: 'Account created successfully. Welcome aboard!', token, user }, 201)
  } catch {
    return json({ error: 'Registration failed. Please try again.' }, 500)
  }
}
