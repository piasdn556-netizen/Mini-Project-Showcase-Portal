import { db } from '@/lib/db'
import { json } from '@/lib/http'
import { getAuthUser } from '@/lib/auth'

/** Returns the authenticated user for the current JWT (used to validate sessions). */
export async function GET(req: Request) {
  try {
    const auth = await getAuthUser(req)
    if (!auth) return json({ error: 'Not authenticated.' }, 401)

    const user = await db.user.findUnique({
      where: { id: auth.id },
      select: { id: true, name: true, email: true, role: true, createdAt: true },
    })
    if (!user) return json({ error: 'Account no longer exists.' }, 401)

    return json({ user })
  } catch {
    return json({ error: 'Unable to verify session.' }, 500)
  }
}
