import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Mini Project Showcase Portal",
  description:
    "Discover. Showcase. Innovate. A centralized platform where college students showcase mini projects and faculty review submissions.",
  keywords: ["college", "projects", "showcase", "students", "faculty", "hackathon"],
  authors: [{ name: "Mini Project Showcase Portal" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Mini Project Showcase Portal",
    description: "Discover. Showcase. Innovate. Browse student mini projects approved by faculty.",
    siteName: "Mini Project Showcase Portal",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
