'use client'

import { useEffect, useSyncExternalStore } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Toaster } from '@/components/ui/sonner'
import { Header } from '@/components/portal/Header'
import { Footer } from '@/components/portal/Footer'
import { HomeView } from '@/components/portal/HomeView'
import { ExploreView } from '@/components/portal/ExploreView'
import { ProjectDetailsView } from '@/components/portal/ProjectDetailsView'
import { AuthView } from '@/components/portal/AuthView'
import { StudentDashboard } from '@/components/portal/StudentDashboard'
import { ProjectForm } from '@/components/portal/ProjectForm'
import { FacultyDashboard } from '@/components/portal/FacultyDashboard'
import { useAuth } from '@/lib/store'
import { api } from '@/lib/api-client'
import { navigate, useHashRoute, type Route } from '@/lib/router'
import type { Role } from '@/lib/types'

// Hydration-safe "mounted" flag (false during SSR, true on the client).
const emptySubscribe = () => () => undefined
const clientSnapshot = () => true
const serverSnapshot = () => false

/** Client-side route guard: enforces login + role before rendering protected views. */
function RequireRole({ role, children }: { role?: Role; children: React.ReactNode }) {
  const user = useAuth((s) => s.user)
  const token = useAuth((s) => s.token)
  const allowed = !!user && !!token && (!role || user.role === role)

  useEffect(() => {
    if (allowed) return
    if (!token || !user) {
      toast.error('Please login to access that page.')
      navigate('/login')
    } else {
      toast.error("You don't have permission to access that page.")
      navigate('/')
    }
  }, [allowed, token, user])

  if (!allowed) return null
  return <>{children}</>
}

function NotFoundView() {
  return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <p className="text-sm font-semibold uppercase tracking-wide text-teal-600">404</p>
      <h1 className="mt-2 text-2xl font-bold text-slate-900">Page not found</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        The page you are looking for does not exist or has moved.
      </p>
      <Button className="mt-6" onClick={() => navigate('/')}>
        Back to Home
      </Button>
    </div>
  )
}

function ViewForRoute({ route }: { route: Route }) {
  const user = useAuth((s) => s.user)
  const segments = route.path.split('/').filter(Boolean)
  const head = segments[0] ?? ''

  switch (head) {
    case '':
      return <HomeView />
    case 'explore':
      return (
        <ExploreView
          key={route.query.get('category') ?? 'all'}
          initialCategory={route.query.get('category')}
        />
      )
    case 'project':
      return segments[1] ? <ProjectDetailsView id={segments[1]} /> : <NotFoundView />
    case 'login':
      return <AuthView mode="login" />
    case 'register':
      return <AuthView mode="register" />
    case 'dashboard':
      return user?.role === 'faculty' ? (
        <RequireRole role="faculty">
          <FacultyDashboard />
        </RequireRole>
      ) : (
        <RequireRole role="student">
          <StudentDashboard />
        </RequireRole>
      )
    case 'add-project':
      return (
        <RequireRole role="student">
          <ProjectForm mode="add" />
        </RequireRole>
      )
    case 'edit-project':
      return segments[1] ? (
        <RequireRole role="student">
          <ProjectForm mode="edit" projectId={segments[1]} />
        </RequireRole>
      ) : (
        <NotFoundView />
      )
    case 'faculty':
      return (
        <RequireRole role="faculty">
          {/* key forces a remount when the ?tab= query changes so the tab state follows the URL */}
          <FacultyDashboard
            key={route.query.get('tab') ?? 'review'}
            initialTab={route.query.get('tab')}
          />
        </RequireRole>
      )
    case 'categories':
      return (
        <RequireRole role="faculty">
          <FacultyDashboard key="categories" initialTab="categories" />
        </RequireRole>
      )
    default:
      return <NotFoundView />
  }
}

export default function Page() {
  const route = useHashRoute()
  const mounted = useSyncExternalStore(emptySubscribe, clientSnapshot, serverSnapshot)

  useEffect(() => {
    // Validate any stored JWT once on load; drop stale sessions.
    const { token } = useAuth.getState()
    if (!token) return
    api('/api/auth/me').catch(() => {
      useAuth.getState().clear()
      toast.error('Your session has expired. Please login again.')
    })
  }, [])

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header route={route} />
      <main className="flex-1">{mounted ? <ViewForRoute route={route} /> : null}</main>
      <Footer />
      <Toaster position="top-center" richColors closeButton />
    </div>
  )
}
