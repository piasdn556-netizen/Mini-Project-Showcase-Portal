'use client'

import { useAuth } from '@/lib/store'

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

interface ApiOptions {
  method?: string
  body?: unknown
  formData?: FormData
}

/** Fetch wrapper that attaches the JWT and normalizes error responses. */
export async function api<T>(path: string, options: ApiOptions = {}): Promise<T> {
  const token = useAuth.getState().token
  const headers: Record<string, string> = {}
  if (token) headers.Authorization = `Bearer ${token}`

  let body: BodyInit | undefined
  if (options.formData) {
    body = options.formData
  } else if (options.body !== undefined) {
    headers['Content-Type'] = 'application/json'
    body = JSON.stringify(options.body)
  }

  const res = await fetch(path, {
    method: options.method ?? (body ? 'POST' : 'GET'),
    headers,
    body,
  })

  const data = (await res.json().catch(() => ({}))) as Record<string, unknown>
  if (!res.ok) {
    const message = typeof data.error === 'string' ? data.error : 'Something went wrong. Please try again.'
    throw new ApiError(message, res.status)
  }
  return data as T
}
