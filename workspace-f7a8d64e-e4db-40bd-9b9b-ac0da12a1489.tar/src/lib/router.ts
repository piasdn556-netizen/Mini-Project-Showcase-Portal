'use client'

import { useSyncExternalStore } from 'react'

export interface Route {
  path: string
  query: URLSearchParams
}

const HOME: Route = { path: '/', query: new URLSearchParams() }

export function parseHash(): Route {
  const raw = typeof window === 'undefined' ? '' : window.location.hash
  const [pathPart, queryPart] = raw.replace(/^#/, '').split('?')
  return { path: pathPart || '/', query: new URLSearchParams(queryPart ?? '') }
}

export function navigate(to: string) {
  const target = to.startsWith('#') ? to.slice(1) : to
  if (window.location.hash === `#${target}`) {
    // Re-render anyway (e.g. re-clicking the same link should do no harm).
    window.dispatchEvent(new HashChangeEvent('hashchange'))
    return
  }
  window.location.hash = target
}

// Cached snapshots so useSyncExternalStore always gets stable references.
let cachedRaw: string | null = null
let cachedRoute: Route = HOME

function getSnapshot(): Route {
  const raw = window.location.hash
  if (raw !== cachedRaw) {
    cachedRaw = raw
    cachedRoute = parseHash()
  }
  return cachedRoute
}

function getServerSnapshot(): Route {
  return HOME
}

function subscribe(onChange: () => void) {
  window.addEventListener('hashchange', onChange)
  return () => window.removeEventListener('hashchange', onChange)
}

/** Minimal hash router: all views live under the single "/" page. */
export function useHashRoute(): Route {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)
}
