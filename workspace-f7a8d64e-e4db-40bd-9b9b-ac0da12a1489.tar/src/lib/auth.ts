import { SignJWT, jwtVerify } from 'jose'

export type Role = 'student' | 'faculty'

export interface AuthPayload {
  id: string
  name: string
  email: string
  role: Role
}

const secret = new TextEncoder().encode(
  process.env.JWT_SECRET || 'dev-only-insecure-secret-change-me'
)

/** Sign a JWT valid for 7 days. */
export async function signToken(payload: AuthPayload): Promise<string> {
  return await new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret)
}

/** Verify a JWT and return its payload, or null when invalid/expired. */
export async function verifyToken(token: string): Promise<AuthPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secret)
    if (typeof payload.id !== 'string' || typeof payload.role !== 'string') return null
    if (payload.role !== 'student' && payload.role !== 'faculty') return null
    return {
      id: payload.id,
      name: typeof payload.name === 'string' ? payload.name : '',
      email: typeof payload.email === 'string' ? payload.email : '',
      role: payload.role,
    }
  } catch {
    return null
  }
}

/**
 * Auth middleware equivalent: reads the `Authorization: Bearer <token>`
 * header and resolves the logged-in user (or null for public requests).
 */
export async function getAuthUser(req: Request): Promise<AuthPayload | null> {
  const header = req.headers.get('authorization') || ''
  const token = header.startsWith('Bearer ') ? header.slice(7).trim() : ''
  if (!token) return null
  return verifyToken(token)
}
