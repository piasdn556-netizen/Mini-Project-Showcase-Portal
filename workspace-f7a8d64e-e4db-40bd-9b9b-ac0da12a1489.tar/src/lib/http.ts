// Small helper to build consistent JSON responses with proper status codes.
export function json(data: unknown, status = 200) {
  return Response.json(data, { status })
}
