export type Role = 'student' | 'faculty'

export interface AuthUser {
  id: string
  name: string
  email: string
  role: Role
}

export type ProjectStatus = 'Pending' | 'Approved' | 'Rejected'

export interface Project {
  id: string
  title: string
  description: string
  technologies: string[]
  teamMembers: string[]
  githubLink: string
  screenshotPath: string | null
  category: string
  batch: string
  status: ProjectStatus
  createdAt: string
  updatedAt: string
  reviewedAt: string | null
  student: { id: string; name: string; email: string }
}

export interface CategoryInfo {
  id: string
  name: string
  projectCount: number
  approvedCount: number
}

export interface Stats {
  total: number
  pending: number
  approved: number
  rejected: number
  byCategory: { name: string; count: number }[]
  byBatch: { name: string; count: number }[]
}
