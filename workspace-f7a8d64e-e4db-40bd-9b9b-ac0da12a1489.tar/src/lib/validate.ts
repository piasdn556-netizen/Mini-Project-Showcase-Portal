/** Shared input validation + sanitization helpers. */

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export function isValidGithubUrl(url: string): boolean {
  return /^https:\/\/github\.com\/[\w.-]+\/[\w.\-/#]*$/.test(url.trim())
}

/** Split "a, b, c" into a clean array of strings. */
export function splitList(value: string): string[] {
  return value
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
}

/** Remove control characters, trim and clamp length of free-form text. */
export function cleanText(value: unknown, max = 2000): string {
  if (typeof value !== 'string') return ''
  return value.replace(/\0/g, '').trim().slice(0, max)
}

export const PROJECT_STATUSES = ['Pending', 'Approved', 'Rejected'] as const
export type ProjectStatus = (typeof PROJECT_STATUSES)[number]

export function isProjectStatus(value: unknown): value is ProjectStatus {
  return typeof value === 'string' && (PROJECT_STATUSES as readonly string[]).includes(value)
}
