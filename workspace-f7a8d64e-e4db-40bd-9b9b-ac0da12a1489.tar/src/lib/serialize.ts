import { Prisma } from '@prisma/client'
import { splitList } from '@/lib/validate'

export type ProjectWithStudent = Prisma.ProjectGetPayload<{
  include: { student: { select: { id: true; name: true; email: true } } }
}>

export interface SerializedProject {
  id: string
  title: string
  description: string
  technologies: string[]
  teamMembers: string[]
  githubLink: string
  screenshotPath: string | null
  category: string
  batch: string
  status: string
  createdAt: string
  updatedAt: string
  reviewedAt: string | null
  student: { id: string; name: string; email: string }
}

/**
 * Convert a Prisma Project record into a safe API response.
 * Technologies / teamMembers are stored comma-separated and exposed as arrays.
 */
export function serializeProject(p: ProjectWithStudent): SerializedProject {
  return {
    id: p.id,
    title: p.title,
    description: p.description,
    technologies: splitList(p.technologies),
    teamMembers: splitList(p.teamMembers),
    githubLink: p.githubLink,
    screenshotPath: p.screenshotPath,
    category: p.category,
    batch: p.batch,
    status: p.status,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
    reviewedAt: p.reviewedAt ? p.reviewedAt.toISOString() : null,
    student: {
      id: p.student.id,
      name: p.student.name,
      email: p.student.email,
    },
  }
}
