/** Shared constants used by both API validation and frontend forms. */
export const BATCH_OPTIONS = ['2022-2026', '2023-2027', '2024-2028', '2025-2029'] as const
