import { mkdir, writeFile, unlink } from 'fs/promises'
import path from 'path'
import crypto from 'crypto'

/**
 * Upload middleware equivalent (Multer replacement):
 * - restricts file types to JPG / PNG / WebP
 * - enforces a 5 MB size limit
 * - generates safe, random filenames (no user-controlled paths)
 */

const UPLOAD_DIR = path.join(process.cwd(), 'uploads')
const ALLOWED_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
}
const MAX_SIZE = 5 * 1024 * 1024 // 5 MB

export type UploadResult =
  | { ok: true; path: string }
  | { ok: false; error: string; status: number }

export async function saveUpload(file: File): Promise<UploadResult> {
  const ext = ALLOWED_TYPES[file.type]
  if (!ext) {
    return { ok: false, error: 'Only JPG, PNG or WebP images are allowed.', status: 400 }
  }
  if (file.size > MAX_SIZE) {
    return { ok: false, error: 'Image must be smaller than 5 MB.', status: 413 }
  }
  if (file.size === 0) {
    return { ok: false, error: 'The uploaded image file is empty.', status: 400 }
  }
  await mkdir(UPLOAD_DIR, { recursive: true })
  const name = `${Date.now()}-${crypto.randomBytes(8).toString('hex')}.${ext}`
  const buffer = Buffer.from(await file.arrayBuffer())
  await writeFile(path.join(UPLOAD_DIR, name), buffer)
  return { ok: true, path: `/api/uploads/${name}` }
}

/** Best-effort removal of an uploaded file (ignores seed/static assets). */
export async function deleteUpload(publicPath?: string | null): Promise<void> {
  if (!publicPath || !publicPath.startsWith('/api/uploads/')) return
  const name = publicPath.replace('/api/uploads/', '')
  if (!/^[A-Za-z0-9._-]+$/.test(name) || name.includes('..')) return
  try {
    await unlink(path.join(UPLOAD_DIR, name))
  } catch {
    // file may already be gone - nothing to do
  }
}
