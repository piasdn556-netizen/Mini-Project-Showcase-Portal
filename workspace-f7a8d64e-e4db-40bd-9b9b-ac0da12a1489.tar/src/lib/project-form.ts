import { db } from '@/lib/db'
import { cleanText, splitList, isValidGithubUrl } from '@/lib/validate'
import { BATCH_OPTIONS } from '@/lib/constants'

/**
 * Shared parser/validator for the Add Project and Edit Project forms.
 * Expects multipart/form-data (like Multer would receive).
 */

export interface ProjectFormData {
  title: string
  description: string
  technologies: string
  teamMembers: string
  githubLink: string
  category: string
  batch: string
}

export type ProjectFormResult =
  | { ok: true; data: ProjectFormData; screenshotFile: File | null }
  | { ok: false; error: string; status: number }

export async function parseProjectForm(form: FormData): Promise<ProjectFormResult> {
  const title = cleanText(form.get('title'), 120)
  const description = cleanText(form.get('description'), 4000)
  const technologies = splitList(cleanText(form.get('technologies'), 500)).join(', ')
  const teamMembers = splitList(cleanText(form.get('teamMembers'), 500)).join(', ')
  const githubLink = cleanText(form.get('githubLink'), 300)
  const category = cleanText(form.get('category'), 60)
  const batch = cleanText(form.get('batch'), 40)

  if (title.length < 3) {
    return { ok: false, error: 'Project title must be at least 3 characters long.', status: 400 }
  }
  if (description.length < 20) {
    return { ok: false, error: 'Project description must be at least 20 characters long.', status: 400 }
  }
  if (!technologies) {
    return { ok: false, error: 'Add at least one technology used in the project.', status: 400 }
  }
  if (!teamMembers) {
    return { ok: false, error: 'Add at least one team member.', status: 400 }
  }
  if (!isValidGithubUrl(githubLink)) {
    return {
      ok: false,
      error: 'GitHub link must look like https://github.com/username/repository',
      status: 400,
    }
  }
  if (!category) {
    return { ok: false, error: 'Please select a project category.', status: 400 }
  }
  if (!(BATCH_OPTIONS as readonly string[]).includes(batch)) {
    return { ok: false, error: 'Please select a valid batch.', status: 400 }
  }

  const categoryExists = await db.category.findFirst({ where: { name: category } })
  if (!categoryExists) {
    return {
      ok: false,
      error: 'The selected category no longer exists. Please pick a category from the list.',
      status: 400,
    }
  }

  const screenshot = form.get('screenshot')
  const screenshotFile = screenshot instanceof File && screenshot.size > 0 ? screenshot : null

  return { ok: true, data: { title, description, technologies, teamMembers, githubLink, category, batch }, screenshotFile }
}
