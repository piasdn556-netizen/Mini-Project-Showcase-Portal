'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { ArrowLeft, Github, ImageIcon, SearchX } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { api, ApiError } from '@/lib/api-client'
import { navigate } from '@/lib/router'
import { formatDate, initials } from '@/components/portal/format'
import { StatusBadge, TechChips } from '@/components/portal/ui-bits'
import type { Project } from '@/lib/types'

function InfoRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-1.5">
      <span className="shrink-0 text-sm text-muted-foreground">{label}</span>
      <span className="text-right text-sm font-medium text-slate-800">{children}</span>
    </div>
  )
}

export function ProjectDetailsView({ id }: { id: string }) {
  const [project, setProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let alive = true
    // Flip into the loading state on the next tick (async) while fetching.
    const loadingTimer = setTimeout(() => {
      if (alive) setLoading(true)
    }, 0)
    api<{ project: Project }>(`/api/projects/${id}`)
      .then((r) => {
        if (!alive) return
        setProject(r.project)
        setError('')
      })
      .catch((e) => {
        if (!alive) return
        setProject(null)
        setError(e instanceof ApiError ? e.message : 'Unable to load this project.')
      })
      .finally(() => {
        if (alive) setLoading(false)
      })
    return () => {
      alive = false
      clearTimeout(loadingTimer)
    }
  }, [id])

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <Button variant="ghost" size="sm" className="gap-1.5 text-slate-600" onClick={() => navigate('/explore')}>
        <ArrowLeft className="h-4 w-4" aria-hidden /> Back to Explore
      </Button>

      {loading ? (
        <div className="mt-4 grid gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <Skeleton className="aspect-video w-full rounded-xl" />
            <Skeleton className="h-40 w-full rounded-xl" />
          </div>
          <Skeleton className="h-80 w-full rounded-xl" />
        </div>
      ) : error || !project ? (
        <div className="mt-8">
          <div className="rounded-xl border border-dashed bg-white px-6 py-14 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-slate-100">
              <SearchX className="h-6 w-6 text-slate-400" aria-hidden />
            </div>
            <h2 className="mt-4 text-lg font-semibold">Project not found</h2>
            <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
              {error || 'This project may be pending review, rejected, or the link is incorrect.'} Public
              visitors can only view faculty-approved projects.
            </p>
            <div className="mt-4">
              <Button onClick={() => navigate('/explore')}>Browse approved projects</Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-4 grid gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <Card className="overflow-hidden p-0">
              <div className="relative aspect-video w-full bg-slate-100">
                {project.screenshotPath ? (
                  <Image
                    src={project.screenshotPath}
                    alt={`${project.title} screenshot`}
                    width={1200}
                    height={675}
                    className="h-full w-full object-cover"
                    unoptimized
                    priority
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center">
                    <ImageIcon className="h-12 w-12 text-slate-300" aria-hidden />
                  </div>
                )}
              </div>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>About this project</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-line text-sm leading-relaxed text-slate-700">
                  {project.description}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Technologies Used</CardTitle>
              </CardHeader>
              <CardContent>
                <TechChips items={project.technologies} max={99} />
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Project Information</CardTitle>
              </CardHeader>
              <CardContent className="divide-y">
                <InfoRow label="Title">{project.title}</InfoRow>
                <InfoRow label="Category">{project.category}</InfoRow>
                <InfoRow label="Batch">{project.batch}</InfoRow>
                <InfoRow label="Status">
                  <StatusBadge status={project.status} />
                </InfoRow>
                <InfoRow label="Submitted">{formatDate(project.createdAt)}</InfoRow>
                {project.reviewedAt && <InfoRow label="Reviewed">{formatDate(project.reviewedAt)}</InfoRow>}
              </CardContent>
            </Card>

            {project.status !== 'Approved' && (
              <div
                className={`rounded-lg border px-3 py-2 text-xs ${
                  project.status === 'Pending'
                    ? 'border-amber-200 bg-amber-50 text-amber-800'
                    : 'border-red-200 bg-red-50 text-red-700'
                }`}
              >
                {project.status === 'Pending'
                  ? 'This project is awaiting faculty review and is not public yet. You can see it because you own it or are faculty.'
                  : 'This project was not approved, so it stays hidden from the public showcase. You can see it because you own it or are faculty.'}
              </div>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Submitted by</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-semibold text-white">
                    {initials(project.student.name)}
                  </span>
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold">{project.student.name}</div>
                    <div className="truncate text-xs text-muted-foreground">{project.student.email}</div>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Team Members</div>
                  <ul className="mt-2 space-y-1">
                    {project.teamMembers.map((m) => (
                      <li key={m} className="text-sm text-slate-700">
                        &bull; {m}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            <a href={project.githubLink} target="_blank" rel="noopener noreferrer" className="block">
              <Button className="w-full gap-2">
                <Github className="h-4 w-4" aria-hidden /> View GitHub Repository
              </Button>
            </a>
          </div>
        </div>
      )}
    </div>
  )
}
