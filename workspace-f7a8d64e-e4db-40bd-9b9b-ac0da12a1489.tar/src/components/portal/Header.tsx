'use client'

import { useState } from 'react'
import { GraduationCap, LayoutDashboard, LogOut, Menu, Plus } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/lib/store'
import { navigate } from '@/lib/router'
import { initials } from '@/components/portal/format'
import type { Route, } from '@/lib/router'
import type { AuthUser } from '@/lib/types'

interface NavItem {
  label: string
  href: string
}

function navItems(user: AuthUser | null): NavItem[] {
  const base: NavItem[] = [
    { label: 'Home', href: '/' },
    { label: 'Explore Projects', href: '/explore' },
  ]
  if (!user) return base
  if (user.role === 'student') {
    return [
      ...base,
      { label: 'My Dashboard', href: '/dashboard' },
      { label: 'Add Project', href: '/add-project' },
    ]
  }
  return [
    ...base,
    { label: 'Faculty Dashboard', href: '/faculty' },
    { label: 'Categories', href: '/faculty?tab=categories' },
  ]
}

function isItemActive(route: Route, href: string): boolean {
  const [path, query] = href.split('?')
  if (route.path !== path) return false
  if (!query) return route.path === '/' || !route.query.get('tab') || route.query.get('tab') === 'review'
  const wanted = new URLSearchParams(query)
  return route.query.get('tab') === wanted.get('tab')
}

export function Header({ route }: { route: Route }) {
  const user = useAuth((s) => s.user)
  const clear = useAuth((s) => s.clear)
  const [mobileOpen, setMobileOpen] = useState(false)

  const items = navItems(user)

  const go = (href: string) => {
    setMobileOpen(false)
    navigate(href)
  }

  const logout = () => {
    clear()
    setMobileOpen(false)
    navigate('/')
    toast.success('Logged out. See you soon!')
  }

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
        <button
          onClick={() => go('/')}
          className="flex shrink-0 items-center gap-2.5"
          aria-label="Go to homepage"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <GraduationCap className="h-5 w-5 text-white" aria-hidden />
          </span>
          <span className="text-left leading-tight">
            <span className="block text-sm font-bold text-slate-900 sm:text-base">Mini Project Showcase Portal</span>
            <span className="block text-[10px] font-semibold tracking-widest text-teal-600">
              DISCOVER &middot; SHOWCASE &middot; INNOVATE
            </span>
          </span>
        </button>

        <nav className="hidden items-center gap-1 md:flex" aria-label="Main navigation">
          {items.map((item) => (
            <Button key={item.href} variant="ghost" size="sm"
              className={isItemActive(route, item.href) ? 'bg-primary/10 font-medium text-primary' : 'text-slate-600'}
              onClick={() => go(item.href)}
            >
              {item.label}
            </Button>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="flex items-center gap-2 rounded-full border bg-white py-1 pl-1 pr-3 transition hover:shadow-sm"
                  aria-label="Open account menu"
                >
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-xs font-semibold text-white">
                    {initials(user.name)}
                  </span>
                  <span className="max-w-[10rem] truncate text-sm font-medium">{user.name}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="truncate text-sm font-semibold">{user.name}</div>
                  <div className="truncate text-xs font-normal text-muted-foreground">{user.email}</div>
                  <Badge variant="secondary" className="mt-1.5 capitalize">{user.role}</Badge>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => go(user.role === 'faculty' ? '/faculty' : '/dashboard')}>
                  <LayoutDashboard className="h-4 w-4" aria-hidden />
                  {user.role === 'faculty' ? 'Faculty Dashboard' : 'My Dashboard'}
                </DropdownMenuItem>
                {user.role === 'student' && (
                  <DropdownMenuItem onClick={() => go('/add-project')}>
                    <Plus className="h-4 w-4" aria-hidden />
                    Add New Project
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="text-red-600 focus:text-red-600">
                  <LogOut className="h-4 w-4" aria-hidden />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button variant="ghost" size="sm" className="text-slate-600" onClick={() => go('/login')}>
                Login
              </Button>
              <Button size="sm" onClick={() => go('/register')}>Register</Button>
            </>
          )}
        </div>

        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <button
              className="flex h-10 w-10 items-center justify-center rounded-lg border md:hidden"
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" aria-hidden />
            </button>
          </SheetTrigger>
          <SheetContent side="right" className="w-72">
            <SheetTitle className="text-left">Navigation</SheetTitle>
            <div className="mt-2 flex flex-col gap-1">
              {items.map((item) => (
                <button
                  key={item.href}
                  onClick={() => go(item.href)}
                  className={`rounded-lg px-3 py-2 text-left text-sm transition ${
                    isItemActive(route, item.href)
                      ? 'bg-primary/10 font-medium text-primary'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <div className="mt-4 border-t pt-4">
              {user ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 px-1">
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-xs font-semibold text-white">
                      {initials(user.name)}
                    </span>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium">{user.name}</div>
                      <div className="truncate text-xs text-muted-foreground">{user.email}</div>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full text-red-600 hover:text-red-600" onClick={logout}>
                    <LogOut className="h-4 w-4" aria-hidden /> Logout
                  </Button>
                </div>
              ) : (
                <div className="grid gap-2">
                  <Button variant="outline" onClick={() => go('/login')}>Login</Button>
                  <Button onClick={() => go('/register')}>Register</Button>
                </div>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
