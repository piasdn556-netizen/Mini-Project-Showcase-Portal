'use client'

import { useEffect, useState } from 'react'
import { Briefcase, Eye, EyeOff, GraduationCap, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { api, ApiError } from '@/lib/api-client'
import { useAuth } from '@/lib/store'
import { navigate } from '@/lib/router'
import { isValidEmail } from '@/lib/validate'
import type { AuthUser } from '@/lib/types'

interface AuthResponse {
  message: string
  token: string
  user: AuthUser
}

export function AuthView({ mode }: { mode: 'login' | 'register' }) {
  const user = useAuth((s) => s.user)
  const setAuth = useAuth((s) => s.setAuth)

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [role, setRole] = useState<'student' | 'faculty'>('student')
  const [showPassword, setShowPassword] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [formError, setFormError] = useState('')
  const [loading, setLoading] = useState(false)

  // Already signed in? Go straight to the role dashboard (also runs after login).
  useEffect(() => {
    if (user) navigate(user.role === 'faculty' ? '/faculty' : '/dashboard')
  }, [user])

  const validate = () => {
    const e: Record<string, string> = {}
    if (mode === 'register' && name.trim().length < 2) e.name = 'Please enter your full name.'
    if (!isValidEmail(email.trim())) e.email = 'Enter a valid email address.'
    if (password.length < 6) e.password = 'Password must be at least 6 characters.'
    if (mode === 'register' && confirmPassword !== password) e.confirmPassword = 'Passwords do not match.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault()
    setFormError('')
    if (!validate()) return
    setLoading(true)
    try {
      const res =
        mode === 'login'
          ? await api<AuthResponse>('/api/auth/login', { body: { email: email.trim(), password } })
          : await api<AuthResponse>('/api/auth/register', {
              body: { name: name.trim(), email: email.trim(), password, role },
            })
      setAuth(res.user, res.token)
      toast.success(res.message)
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const fieldError = (key: string) =>
    errors[key] ? <p className="mt-1 text-xs text-red-600">{errors[key]}</p> : null

  const passwordInput = (value: string, onChange: (v: string) => void, autoComplete: string) => (
    <div className="relative">
      <Input
        type={showPassword ? 'text' : 'password'}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Enter your password"
        autoComplete={autoComplete}
        className="pr-10"
      />
      <button
        type="button"
        onClick={() => setShowPassword((v) => !v)}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition hover:text-slate-600"
        aria-label={showPassword ? 'Hide password' : 'Show password'}
      >
        {showPassword ? <EyeOff className="h-4 w-4" aria-hidden /> : <Eye className="h-4 w-4" aria-hidden />}
      </button>
    </div>
  )

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-10">
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="flex flex-col items-center text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
              <GraduationCap className="h-6 w-6 text-white" aria-hidden />
            </span>
            <h1 className="mt-4 text-xl font-bold text-slate-900">
              {mode === 'login' ? 'Welcome back' : 'Create your account'}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {mode === 'login'
                ? 'Sign in to submit projects or review submissions.'
                : 'Join the portal as a student or faculty member.'}
            </p>
          </div>

          {formError && (
            <div role="alert" className="mt-5 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
              {formError}
            </div>
          )}

          <form className="mt-5 space-y-4" onSubmit={submit} noValidate>
            {mode === 'register' && (
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Aarav Sharma"
                  autoComplete="name"
                  className="mt-1.5"
                />
                {fieldError('name')}
              </div>
            )}

            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@college.edu"
                autoComplete="email"
                className="mt-1.5"
              />
              {fieldError('email')}
            </div>

            <div>
              <Label htmlFor="password">Password</Label>
              <div className="mt-1.5">
                {passwordInput(password, setPassword, mode === 'login' ? 'current-password' : 'new-password')}
              </div>
              {fieldError('password')}
            </div>

            {mode === 'register' && (
              <>
                <div>
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <div className="mt-1.5">
                    {passwordInput(confirmPassword, setConfirmPassword, 'new-password')}
                  </div>
                  {fieldError('confirmPassword')}
                </div>

                <div>
                  <Label>Register as</Label>
                  <div className="mt-1.5 grid grid-cols-2 gap-2">
                    {(['student', 'faculty'] as const).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRole(r)}
                        className={`flex items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-sm font-medium capitalize transition ${
                          role === r
                            ? 'border-primary bg-primary/5 text-primary'
                            : 'border-input text-slate-600 hover:bg-slate-50'
                        }`}
                        aria-pressed={role === r}
                      >
                        {r === 'student' ? (
                          <GraduationCap className="h-4 w-4" aria-hidden />
                        ) : (
                          <Briefcase className="h-4 w-4" aria-hidden />
                        )}
                        {r === 'student' ? 'Student' : 'Faculty'}
                      </button>
                    ))}
                  </div>
                  {role === 'faculty' && (
                    <p className="mt-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
                      Demo note: faculty self-registration is enabled for this hackathon. In production,
                      faculty accounts are created and verified by the college.
                    </p>
                  )}
                </div>
              </>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
              {mode === 'login' ? 'Sign In' : 'Create Account'}
            </Button>
          </form>

          <div className="mt-4 text-center text-sm text-muted-foreground">
            {mode === 'login' ? (
              <>
                New to the portal?{' '}
                <button className="font-medium text-primary hover:underline" onClick={() => navigate('/register')}>
                  Create an account
                </button>
              </>
            ) : (
              <>
                Already have an account?{' '}
                <button className="font-medium text-primary hover:underline" onClick={() => navigate('/login')}>
                  Sign in
                </button>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {mode === 'login' && (
        <div className="mt-4 rounded-lg border bg-slate-50 p-3 text-xs leading-relaxed text-slate-600">
          <span className="font-semibold text-slate-700">Demo accounts:</span> Faculty &mdash;{' '}
          <span className="font-mono">faculty@college.edu / Faculty@123</span> &nbsp;&middot;&nbsp; Student &mdash;{' '}
          <span className="font-mono">aarav@college.edu / Student@123</span>
        </div>
      )}
    </div>
  )
}
