'use client'

import { useEffect, useState } from 'react'
import { Search, SearchX, X } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { api } from '@/lib/api-client'
import { ProjectCard } from '@/components/portal/ProjectCard'
import { EmptyState } from '@/components/portal/ui-bits'
import type { CategoryInfo, Project } from '@/lib/types'

export function ExploreView({ initialCategory }: { initialCategory?: string | null }) {
  const [q, setQ] = useState('')
  const [tech, setTech] = useState('')
  const [category, setCategory] = useState(initialCategory ?? 'all')
  const [batch, setBatch] = useState('all')
  const [sort, setSort] = useState('newest')
  const [dq, setDq] = useState('')
  const [dtech, setDtech] = useState('')

  const [projects, setProjects] = useState<Project[]>([])
  const [total, setTotal] = useState(0)
  const [categories, setCategories] = useState<CategoryInfo[]>([])
  const [batches, setBatches] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [firstLoad, setFirstLoad] = useState(true)

  // Debounce text inputs so we do not hammer the API on every keystroke.
  useEffect(() => {
    const t = setTimeout(() => {
      setDq(q)
      setDtech(tech)
    }, 350)
    return () => clearTimeout(t)
  }, [q, tech])

  // Static option lists (all batches / all categories).
  useEffect(() => {
    api<{ categories: CategoryInfo[] }>('/api/categories')
      .then((r) => setCategories(r.categories))
      .catch(() => undefined)
    api<{ projects: Project[] }>('/api/projects')
      .then((r) => {
        const set = new Set(r.projects.map((p) => p.batch))
        setBatches([...set].sort())
      })
      .catch(() => undefined)
  }, [])

  useEffect(() => {
    let alive = true
    const params = new URLSearchParams()
    if (dq.trim()) params.set('q', dq.trim())
    if (dtech.trim()) params.set('tech', dtech.trim())
    if (category !== 'all') params.set('category', category)
    if (batch !== 'all') params.set('batch', batch)
    params.set('sort', sort)
    // Flip into the loading state on the next tick (async) so the previous
    // results stay visible until the fresh response arrives.
    const loadingTimer = setTimeout(() => {
      if (alive) setLoading(true)
    }, 0)
    api<{ projects: Project[]; total: number }>(`/api/projects?${params.toString()}`)
      .then((r) => {
        if (!alive) return
        setProjects(r.projects)
        setTotal(r.total)
      })
      .catch(() => {
        if (alive) toast.error('Could not load projects. Please try again.')
      })
      .finally(() => {
        if (!alive) return
        setLoading(false)
        setFirstLoad(false)
      })
    return () => {
      alive = false
      clearTimeout(loadingTimer)
    }
  }, [dq, dtech, category, batch, sort])

  const hasFilters = q !== '' || tech !== '' || category !== 'all' || batch !== 'all' || sort !== 'newest'

  const clearFilters = () => {
    setQ('')
    setTech('')
    setCategory('all')
    setBatch('all')
    setSort('newest')
    setDq('')
    setDtech('')
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="text-2xl font-bold tracking-tight text-slate-900">Explore Projects</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Every project below has been reviewed and approved by faculty.
      </p>

      <div className="mt-6 rounded-xl border bg-white p-4 shadow-sm">
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search by title..."
              className="pl-9"
              aria-label="Search by project title"
            />
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
            <Input
              value={tech}
              onChange={(e) => setTech(e.target.value)}
              placeholder="Search by technology (e.g. Python)"
              className="pl-9"
              aria-label="Search by technology"
            />
          </div>
          <div>
            <Label className="sr-only" htmlFor="filter-category">Filter by category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger id="filter-category" aria-label="Filter by category">
                <SelectValue placeholder="All categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="sr-only" htmlFor="filter-batch">Filter by batch</Label>
              <Select value={batch} onValueChange={setBatch}>
                <SelectTrigger id="filter-batch" aria-label="Filter by batch">
                  <SelectValue placeholder="All batches" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All batches</SelectItem>
                  {batches.map((b) => (
                    <SelectItem key={b} value={b}>{b}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="sr-only" htmlFor="filter-sort">Sort projects</Label>
              <Select value={sort} onValueChange={setSort}>
                <SelectTrigger id="filter-sort" aria-label="Sort projects">
                  <SelectValue placeholder="Newest first" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest first</SelectItem>
                  <SelectItem value="oldest">Oldest first</SelectItem>
                  <SelectItem value="title">Title A&ndash;Z</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between">
          <span className="text-sm text-muted-foreground">
            {loading ? 'Searching\u2026' : `${total} project${total === 1 ? '' : 's'} found`}
          </span>
          {hasFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters} className="text-slate-600">
              <X className="h-4 w-4" aria-hidden /> Clear Filters
            </Button>
          )}
        </div>
      </div>

      <div className="mt-6">
        {loading && firstLoad ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="rounded-xl border bg-white p-4">
                <Skeleton className="aspect-[16/10] w-full rounded-lg" />
                <Skeleton className="mt-4 h-5 w-3/4" />
                <Skeleton className="mt-2 h-4 w-full" />
                <Skeleton className="mt-2 h-4 w-2/3" />
              </div>
            ))}
          </div>
        ) : projects.length > 0 ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((p) => (
              <ProjectCard key={p.id} project={p} />
            ))}
          </div>
        ) : hasFilters ? (
          <EmptyState
            icon={SearchX}
            title="No projects match your filters"
            description="Try a different keyword, technology, category or batch — or clear all filters to see every approved project."
          >
            <Button variant="outline" onClick={clearFilters}>
              <X className="h-4 w-4" aria-hidden /> Clear Filters
            </Button>
          </EmptyState>
        ) : (
          <EmptyState
            icon={SearchX}
            title="Nothing to show yet"
            description="No projects have been approved yet. Approved submissions will appear here automatically."
          />
        )}
      </div>
    </div>
  )
}
