'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, CloudUpload, Loader2, Plus, X } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { api, ApiError } from '@/lib/api-client'
import { navigate } from '@/lib/router'
import { isValidGithubUrl } from '@/lib/validate'
import { BATCH_OPTIONS } from '@/lib/constants'
import { EmptyState } from '@/components/portal/ui-bits'
import type { CategoryInfo, Project } from '@/lib/types'

const MAX_FILE_SIZE = 5 * 1024 * 1024
const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp']

export function ProjectForm({ mode, projectId }: { mode: 'add' | 'edit'; projectId?: string }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [techInput, setTechInput] = useState('')
  const [techs, setTechs] = useState<string[]>([])
  const [teamMembers, setTeamMembers] = useState('')
  const [githubLink, setGithubLink] = useState('')
  const [category, setCategory] = useState('')
  const [batch, setBatch] = useState('')

  const [categories, setCategories] = useState<CategoryInfo[]>([])
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [replaced, setReplaced] = useState(false)

  const [errors, setErrors] = useState<Record<string, string>>({})
  const [formError, setFormError] = useState('')
  const [loading, setLoading] = useState(mode === 'edit')
  const [loadError, setLoadError] = useState('')
  const [saving, setSaving] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  // Category options for the select.
  useEffect(() => {
    api<{ categories: CategoryInfo[] }>('/api/categories')
      .then((r) => setCategories(r.categories))
      .catch(() => toast.error('Could not load categories. Please refresh the page.'))
  }, [])

  // Load the project in edit mode (loading starts as true for edits).
  useEffect(() => {
    if (mode !== 'edit' || !projectId) return
    let alive = true
    api<{ project: Project }>(`/api/projects/${projectId}`)
      .then((r) => {
        if (!alive) return
        const p = r.project
        if (p.status !== 'Pending') {
          setLoadError('This project has already been reviewed, so it can no longer be edited.')
        }
        setTitle(p.title)
        setDescription(p.description)
        setTechs(p.technologies)
        setTeamMembers(p.teamMembers.join(', '))
        setGithubLink(p.githubLink)
        setCategory(p.category)
        setBatch(p.batch)
        setPreviewUrl(p.screenshotPath)
      })
      .catch((e) => {
        if (alive) setLoadError(e instanceof ApiError ? e.message : 'Unable to load this project.')
      })
      .finally(() => {
        if (alive) setLoading(false)
      })
    return () => {
      alive = false
    }
  }, [mode, projectId])

  // Release blob URLs when replaced or on unmount.
  useEffect(() => {
    return () => {
      if (previewUrl && previewUrl.startsWith('blob:')) URL.revokeObjectURL(previewUrl)
    }
  }, [previewUrl])

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] ?? null
    e.target.value = '' // allow re-selecting the same file
    if (!file) return
    if (!ACCEPTED_TYPES.includes(file.type)) {
      toast.error('Only JPG, PNG or WebP images are allowed.')
      return
    }
    if (file.size > MAX_FILE_SIZE) {
      toast.error('Image must be smaller than 5 MB.')
      return
    }
    if (previewUrl && previewUrl.startsWith('blob:')) URL.revokeObjectURL(previewUrl)
    setScreenshotFile(file)
    setPreviewUrl(URL.createObjectURL(file))
    setReplaced(true)
  }

  const removeFile = () => {
    if (previewUrl && previewUrl.startsWith('blob:')) URL.revokeObjectURL(previewUrl)
    setScreenshotFile(null)
    setPreviewUrl(null)
    setReplaced(false)
  }

  const addTechs = (raw: string) => {
    const parts = raw.split(',').map((s) => s.trim()).filter(Boolean)
    if (!parts.length) return
    setTechs((prev) => {
      const seen = new Set(prev.map((t) => t.toLowerCase()))
      const next = [...prev]
      for (const part of parts) {
        if (!seen.has(part.toLowerCase())) {
          next.push(part)
          seen.add(part.toLowerCase())
        }
      }
      return next
    })
    setTechInput('')
  }

  const onTechKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault()
      addTechs(techInput)
    }
    if (e.key === 'Backspace' && !techInput && techs.length) {
      setTechs((t) => t.slice(0, -1))
    }
  }

  const validate = () => {
    const e: Record<string, string> = {}
    if (title.trim().length < 3) e.title = 'Title must be at least 3 characters.'
    if (description.trim().length < 20) e.description = 'Description must be at least 20 characters.'
    if (!techs.length) e.technologies = 'Add at least one technology.'
    if (!teamMembers.trim()) e.teamMembers = 'Add at least one team member.'
    if (!isValidGithubUrl(githubLink)) e.githubLink = 'Use the format https://github.com/username/repository'
    if (!category) e.category = 'Select a category.'
    if (!batch) e.batch = 'Select your batch.'
    if (mode === 'add' && !screenshotFile) e.screenshot = 'Upload a project screenshot or logo.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault()
    setFormError('')
    if (!validate()) return
    setSaving(true)
    try {
      const fd = new FormData()
      fd.append('title', title.trim())
      fd.append('description', description.trim())
      fd.append('technologies', techs.join(', '))
      fd.append('teamMembers', teamMembers.trim())
      fd.append('githubLink', githubLink.trim())
      fd.append('category', category)
      fd.append('batch', batch)
      if (screenshotFile) fd.append('screenshot', screenshotFile)

      const res =
        mode === 'add'
          ? await api<{ message: string }>('/api/projects/add', { formData: fd })
          : await api<{ message: string }>(`/api/projects/${projectId}`, { method: 'PUT', formData: fd })
      toast.success(res.message)
      navigate('/dashboard')
    } catch (e) {
      setFormError(e instanceof ApiError ? e.message : 'Submission failed. Please try again.')
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } finally {
      setSaving(false)
    }
  }

  const fieldError = (key: string) =>
    errors[key] ? <p className="mt-1 text-xs text-red-600">{errors[key]}</p> : null

  if (loading) {
    return (
      <div className="mx-auto max-w-3xl space-y-4 px-4 py-8">
        <Skeleton className="h-9 w-64" />
        <Skeleton className="h-96 w-full rounded-xl" />
      </div>
    )
  }

  if (loadError) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-8">
        <EmptyState
          icon={CloudUpload}
          title="This project cannot be edited"
          description={loadError + ' Only projects that are still pending faculty review can be changed.'}
        >
          <Button onClick={() => navigate('/dashboard')}>Back to My Dashboard</Button>
        </EmptyState>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <Button variant="ghost" size="sm" className="gap-1.5 text-slate-600" onClick={() => navigate('/dashboard')}>
        <ArrowLeft className="h-4 w-4" aria-hidden /> Back to Dashboard
      </Button>
      <h1 className="mt-2 text-2xl font-bold tracking-tight text-slate-900">
        {mode === 'add' ? 'Add New Project' : 'Edit Project'}
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {mode === 'add'
          ? 'Fill in the details below. Your submission will be reviewed by faculty before it appears publicly.'
          : 'Update your project details. It stays pending until faculty review it.'}
      </p>

      {formError && (
        <div role="alert" className="mt-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          {formError}
        </div>
      )}

      <form className="mt-6" onSubmit={submit} noValidate>
        <Card className="shadow-sm">
          <CardContent className="space-y-6 p-6">
            {/* Project details */}
            <section>
              <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Project Details</h2>
              <div className="mt-3 space-y-4">
                <div>
                  <Label htmlFor="title">Project Title</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Smart Attendance System"
                    className="mt-1.5"
                  />
                  {fieldError('title')}
                </div>
                <div>
                  <Label htmlFor="description">Project Description</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="What does your project do? What problem does it solve? How does it work?"
                    rows={5}
                    className="mt-1.5"
                  />
                  <div className="mt-1 flex items-center justify-between">
                    {errors.description ? (
                      <p className="text-xs text-red-600">{errors.description}</p>
                    ) : (
                      <span />
                    )}
                    <span className="text-xs text-muted-foreground">{description.length} characters</span>
                  </div>
                </div>
              </div>
            </section>

            <Separator />

            {/* Technical details */}
            <section>
              <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Technical Details</h2>
              <div className="mt-3 space-y-4">
                <div>
                  <Label htmlFor="technologies">Technologies Used</Label>
                  {techs.length > 0 && (
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {techs.map((t) => (
                        <span
                          key={t}
                          className="inline-flex items-center gap-1 rounded-md bg-primary/10 px-2 py-1 text-xs font-medium text-primary"
                        >
                          {t}
                          <button
                            type="button"
                            onClick={() => setTechs((prev) => prev.filter((x) => x !== t))}
                            aria-label={`Remove ${t}`}
                            className="rounded p-0.5 hover:bg-primary/20"
                          >
                            <X className="h-3 w-3" aria-hidden />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                  <Input
                    id="technologies"
                    value={techInput}
                    onChange={(e) => setTechInput(e.target.value)}
                    onKeyDown={onTechKeyDown}
                    onBlur={() => techInput.trim() && addTechs(techInput)}
                    placeholder="Type a technology and press Enter (e.g. Python, React, IoT)"
                    className="mt-2"
                  />
                  <p className="mt-1 text-xs text-muted-foreground">
                    Press Enter or comma to add. You can also paste comma-separated values.
                  </p>
                  {fieldError('technologies')}
                </div>
                <div>
                  <Label htmlFor="teamMembers">Team Members</Label>
                  <Input
                    id="teamMembers"
                    value={teamMembers}
                    onChange={(e) => setTeamMembers(e.target.value)}
                    placeholder="e.g. Aarav Sharma, Kavya Iyer"
                    className="mt-1.5"
                  />
                  <p className="mt-1 text-xs text-muted-foreground">Separate multiple names with commas.</p>
                  {fieldError('teamMembers')}
                </div>
                <div>
                  <Label htmlFor="githubLink">GitHub Repository Link</Label>
                  <Input
                    id="githubLink"
                    type="url"
                    value={githubLink}
                    onChange={(e) => setGithubLink(e.target.value)}
                    placeholder="https://github.com/username/repository"
                    className="mt-1.5"
                  />
                  {fieldError('githubLink')}
                </div>
              </div>
            </section>

            <Separator />

            {/* Classification */}
            <section>
              <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Classification</h2>
              <div className="mt-3 grid gap-4 sm:grid-cols-2">
                <div>
                  <Label>Project Category</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger className="mt-1.5" aria-label="Project category">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((c) => (
                        <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {fieldError('category')}
                </div>
                <div>
                  <Label>Batch</Label>
                  <Select value={batch} onValueChange={setBatch}>
                    <SelectTrigger className="mt-1.5" aria-label="Batch">
                      <SelectValue placeholder="Select your batch" />
                    </SelectTrigger>
                    <SelectContent>
                      {BATCH_OPTIONS.map((b) => (
                        <SelectItem key={b} value={b}>{b}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {fieldError('batch')}
                </div>
              </div>
            </section>

            <Separator />

            {/* Screenshot */}
            <section>
              <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Screenshot</h2>
              <input
                ref={fileRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={onFileChange}
              />
              {previewUrl ? (
                <div className="mt-3 rounded-xl border p-3">
                  <img
                    src={previewUrl}
                    alt="Project screenshot preview"
                    className="max-h-64 w-full rounded-lg object-contain"
                  />
                  <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                    <span className="truncate text-xs text-muted-foreground">
                      {screenshotFile
                        ? `${screenshotFile.name} (${Math.round(screenshotFile.size / 1024)} KB)${replaced && mode === 'edit' ? ' — will replace the current image' : ''}`
                        : 'Current screenshot'}
                    </span>
                    <div className="flex gap-2">
                      <Button type="button" variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                        Replace image
                      </Button>
                      {mode === 'add' && (
                        <Button type="button" variant="ghost" size="sm" className="text-red-600 hover:text-red-600" onClick={removeFile}>
                          Remove
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="mt-3 flex w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed px-6 py-10 text-center transition hover:bg-slate-50"
                >
                  <CloudUpload className="h-8 w-8 text-slate-400" aria-hidden />
                  <span className="text-sm font-medium text-slate-700">Click to upload</span>
                  <span className="text-xs text-muted-foreground">JPG, PNG or WebP &middot; max 5 MB</span>
                </button>
              )}
              {fieldError('screenshot')}
            </section>

            <div className="flex flex-wrap justify-end gap-3 border-t pt-4">
              <Button type="button" variant="outline" onClick={() => navigate('/dashboard')}>
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
                {mode === 'add' ? 'Submit for Review' : 'Save Changes'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>

      <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
        <Plus className="h-3.5 w-3.5" aria-hidden />
        New submissions start as Pending — only faculty can change the approval status.
      </p>
    </div>
  )
}
