'use client'

import { useCallback, useEffect, useState } from 'react'
import {
  CheckCircle2,
  Clock,
  Eye,
  FolderKanban,
  FolderOpen,
  Lock,
  Pencil,
  Plus,
  Trash2,
  XCircle,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { api, ApiError } from '@/lib/api-client'
import { navigate } from '@/lib/router'
import { formatDate } from '@/components/portal/format'
import { EmptyState, StatCard, StatusBadge, TechChips } from '@/components/portal/ui-bits'
import type { Project } from '@/lib/types'

export function StudentDashboard() {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [deleteTarget, setDeleteTarget] = useState<Project | null>(null)
  const [deleting, setDeleting] = useState(false)

  const load = useCallback(() => {
    api<{ projects: Project[] }>('/api/projects/mine')
      .then((r) => setProjects(r.projects))
      .catch((e) => toast.error(e instanceof ApiError ? e.message : 'Could not load your projects.'))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const pending = projects.filter((p) => p.status === 'Pending').length
  const approved = projects.filter((p) => p.status === 'Approved').length
  const rejected = projects.filter((p) => p.status === 'Rejected').length

  const confirmDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await api<{ message: string }>(`/api/projects/${deleteTarget.id}`, { method: 'DELETE' })
      toast.success(res.message)
      setDeleteTarget(null)
      load()
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Could not delete the project.')
      setDeleteTarget(null)
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">My Dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Track your submissions and their faculty review status.
          </p>
        </div>
        <Button onClick={() => navigate('/add-project')}>
          <Plus className="h-4 w-4" aria-hidden /> Add New Project
        </Button>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={FolderKanban} label="Total Projects" value={loading ? '—' : projects.length} tone="navy" />
        <StatCard icon={Clock} label="Pending" value={loading ? '—' : pending} tone="amber" />
        <StatCard icon={CheckCircle2} label="Approved" value={loading ? '—' : approved} tone="green" />
        <StatCard icon={XCircle} label="Rejected" value={loading ? '—' : rejected} tone="red" />
      </div>

      <h2 className="mt-10 text-lg font-semibold text-slate-900">My Projects</h2>

      <div className="mt-4">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
        ) : projects.length === 0 ? (
          <EmptyState
            icon={FolderOpen}
            title="No projects yet"
            description="Submit your first mini project with a screenshot and GitHub link — faculty will review it before it goes public."
          >
            <Button onClick={() => navigate('/add-project')}>
              <Plus className="h-4 w-4" aria-hidden /> Add New Project
            </Button>
          </EmptyState>
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden overflow-x-auto rounded-xl border bg-white shadow-sm scrollbar-thin md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Project Title</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Technologies</TableHead>
                    <TableHead>Batch</TableHead>
                    <TableHead>Submitted</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {projects.map((p) => {
                    const editable = p.status === 'Pending'
                    return (
                      <TableRow key={p.id}>
                        <TableCell className="max-w-[16rem]">
                          <div className="truncate font-medium text-slate-900">{p.title}</div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">{p.category}</TableCell>
                        <TableCell>
                          <TechChips items={p.technologies} max={2} />
                        </TableCell>
                        <TableCell className="whitespace-nowrap">{p.batch}</TableCell>
                        <TableCell className="whitespace-nowrap">{formatDate(p.createdAt)}</TableCell>
                        <TableCell>
                          <StatusBadge status={p.status} />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => navigate(`/project/${p.id}`)}
                              aria-label={`View ${p.title}`}
                              title="View details"
                            >
                              <Eye className="h-4 w-4" aria-hidden />
                            </Button>
                            {editable ? (
                              <>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => navigate(`/edit-project/${p.id}`)}
                                  aria-label={`Edit ${p.title}`}
                                  title="Edit project"
                                >
                                  <Pencil className="h-4 w-4" aria-hidden />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-red-600 hover:text-red-600"
                                  onClick={() => setDeleteTarget(p)}
                                  aria-label={`Delete ${p.title}`}
                                  title="Delete project"
                                >
                                  <Trash2 className="h-4 w-4" aria-hidden />
                                </Button>
                              </>
                            ) : (
                              <span
                                className="flex items-center gap-1 pr-2 text-xs text-muted-foreground"
                                title="Only pending projects can be edited or deleted"
                              >
                                <Lock className="h-3.5 w-3.5" aria-hidden /> Locked
                              </span>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>

            {/* Mobile cards */}
            <div className="space-y-3 md:hidden">
              {projects.map((p) => {
                const editable = p.status === 'Pending'
                return (
                  <Card key={p.id} className="p-4">
                    <CardContent className="p-0">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div className="truncate font-medium text-slate-900">{p.title}</div>
                          <div className="mt-0.5 text-xs text-muted-foreground">
                            {p.category} &middot; Batch {p.batch}
                          </div>
                          <div className="mt-0.5 text-xs text-muted-foreground">
                            Submitted {formatDate(p.createdAt)}
                          </div>
                        </div>
                        <StatusBadge status={p.status} />
                      </div>
                      <div className="mt-3">
                        <TechChips items={p.technologies} max={3} />
                      </div>
                      <div className="mt-3 flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={() => navigate(`/project/${p.id}`)}
                        >
                          <Eye className="h-4 w-4" aria-hidden /> View
                        </Button>
                        {editable ? (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              className="flex-1"
                              onClick={() => navigate(`/edit-project/${p.id}`)}
                            >
                              <Pencil className="h-4 w-4" aria-hidden /> Edit
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-600 hover:text-red-600"
                              onClick={() => setDeleteTarget(p)}
                              aria-label={`Delete ${p.title}`}
                            >
                              <Trash2 className="h-4 w-4" aria-hidden />
                            </Button>
                          </>
                        ) : (
                          <span
                            className="flex flex-1 items-center justify-center gap-1 text-xs text-muted-foreground"
                            title="Only pending projects can be edited or deleted"
                          >
                            <Lock className="h-3.5 w-3.5" aria-hidden /> Locked after review
                          </span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </>
        )}
      </div>

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this project?</AlertDialogTitle>
            <AlertDialogDescription>
              &ldquo;{deleteTarget?.title}&rdquo; will be permanently removed along with its screenshot. This
              action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 text-white hover:bg-red-700"
              disabled={deleting}
              onClick={(e) => {
                e.preventDefault()
                confirmDelete()
              }}
            >
              {deleting ? 'Deleting…' : 'Delete Project'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
