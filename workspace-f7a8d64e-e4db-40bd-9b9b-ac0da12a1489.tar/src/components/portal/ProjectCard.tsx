'use client'

import Image from 'next/image'
import { ArrowRight, ImageIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { TechChips } from '@/components/portal/ui-bits'
import { navigate } from '@/lib/router'
import type { Project } from '@/lib/types'

export function ProjectCard({ project }: { project: Project }) {
  return (
    <Card className="group overflow-hidden p-0 transition-shadow hover:shadow-md">
      <div className="relative aspect-[16/10] w-full overflow-hidden bg-slate-100">
        {project.screenshotPath ? (
          <Image
            src={project.screenshotPath}
            alt={`${project.title} screenshot`}
            width={672}
            height={420}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
            unoptimized
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200">
            <ImageIcon className="h-10 w-10 text-slate-300" aria-hidden />
          </div>
        )}
        <span className="absolute left-3 top-3 rounded-full bg-white/95 px-2.5 py-1 text-xs font-medium text-primary shadow-sm">
          {project.category}
        </span>
      </div>
      <CardContent className="p-4">
        <h3 className="line-clamp-1 font-semibold group-hover:text-primary">{project.title}</h3>
        <p className="mt-1 line-clamp-2 min-h-[2.5rem] text-sm text-muted-foreground">{project.description}</p>
        <div className="mt-3">
          <TechChips items={project.technologies} />
        </div>
        <div className="mt-4 flex items-center justify-between border-t pt-3">
          <div className="truncate text-xs text-muted-foreground">
            Batch {project.batch} &middot; {project.student.name}
          </div>
          <Button
            size="sm"
            variant="ghost"
            className="gap-1 text-primary hover:text-primary"
            onClick={() => navigate(`/project/${project.id}`)}
          >
            View Details
            <ArrowRight className="h-3.5 w-3.5" aria-hidden />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
