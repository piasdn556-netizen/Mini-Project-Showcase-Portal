'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import {
  CheckCircle2,
  ClipboardCheck,
  CloudUpload,
  Compass,
  FolderOpen,
  Sparkles,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { api } from '@/lib/api-client'
import { navigate } from '@/lib/router'
import { useAuth } from '@/lib/store'
import { ProjectCard } from '@/components/portal/ProjectCard'
import { EmptyState } from '@/components/portal/ui-bits'
import type { CategoryInfo, Project } from '@/lib/types'

const INFO_CARDS = [
  {
    icon: CloudUpload,
    title: 'Upload Projects',
    text: 'Students submit project details, screenshots and GitHub links through a guided form. Every submission starts as Pending.',
  },
  {
    icon: ClipboardCheck,
    title: 'Faculty Review',
    text: 'Faculty inspect each submission and approve or reject it. Approved projects become publicly visible instantly.',
  },
  {
    icon: Compass,
    title: 'Explore Innovations',
    text: 'Anyone can browse the showcase, search by title or technology, filter by category and batch, and open GitHub repositories.',
  },
]

export function HomeView() {
  const user = useAuth((s) => s.user)
  const [featured, setFeatured] = useState<Project[]>([])
  const [totalApproved, setTotalApproved] = useState(0)
  const [categories, setCategories] = useState<CategoryInfo[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let alive = true
    Promise.all([
      api<{ projects: Project[]; total: number }>('/api/projects?sort=newest&limit=6'),
      api<{ categories: CategoryInfo[] }>('/api/categories'),
    ])
      .then(([projectsRes, categoriesRes]) => {
        if (!alive) return
        setFeatured(projectsRes.projects)
        setTotalApproved(projectsRes.total)
        setCategories(categoriesRes.categories)
      })
      .catch(() => {
        if (alive) toast.error('Could not load the showcase. Please refresh the page.')
      })
      .finally(() => {
        if (alive) setLoading(false)
      })
    return () => {
      alive = false
    }
  }, [])

  const submitProject = () => {
    if (!user) {
      toast.info('Register as a student to submit your project.')
      navigate('/register')
      return
    }
    if (user.role === 'student') {
      navigate('/add-project')
    } else {
      toast.info('You are logged in as faculty. Use the Faculty Dashboard to review submissions.')
      navigate('/faculty')
    }
  }

  const batches = new Set(featured.map((p) => p.batch)).size

  return (
    <div>
      {/* Hero */}
      <section className="border-b bg-gradient-to-b from-slate-50 to-white">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 lg:grid-cols-2 lg:items-center lg:py-20">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/15 bg-white px-3 py-1 text-xs font-medium text-primary">
              <Sparkles className="h-3.5 w-3.5 text-teal-600" aria-hidden />
              College Mini Project Showcase
            </span>
            <h1 className="mt-4 text-4xl font-bold tracking-tight text-slate-900 md:text-5xl">
              Showcase Your Ideas.
              <br />
              <span className="text-teal-600">Inspire Innovation.</span>
            </h1>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-muted-foreground">
              Mini Project Showcase Portal is the central hub where students publish academic mini
              projects with screenshots, technologies and GitHub repositories &mdash; faculty review every
              submission before it goes live for the whole college to explore.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button size="lg" onClick={() => navigate('/explore')}>Explore Projects</Button>
              <Button size="lg" variant="outline" onClick={submitProject}>Submit Your Project</Button>
            </div>
            <div className="mt-8 flex gap-8">
              <div>
                <div className="text-2xl font-bold text-slate-900">{loading ? '—' : totalApproved}</div>
                <div className="text-xs text-muted-foreground">Approved Projects</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">{loading ? '—' : categories.length}</div>
                <div className="text-xs text-muted-foreground">Project Categories</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">{loading ? '—' : batches}</div>
                <div className="text-xs text-muted-foreground">Batches Showcased</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <Image
              src="/seed/hero.png"
              alt="Students showcasing their technology projects on campus"
              width={1344}
              height={768}
              className="rounded-2xl border shadow-lg"
              unoptimized
              priority
            />
            <div className="absolute -bottom-5 left-6 flex items-center gap-3 rounded-xl border bg-white px-4 py-3 shadow-lg">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-100">
                <CheckCircle2 className="h-4 w-4 text-emerald-600" aria-hidden />
              </span>
              <div>
                <div className="text-sm font-semibold text-slate-900">Faculty approved</div>
                <div className="text-xs text-muted-foreground">then instantly public</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Info cards */}
      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-4 md:grid-cols-3">
          {INFO_CARDS.map(({ icon: Icon, title, text }) => (
            <Card key={title} className="shadow-sm">
              <CardContent className="p-6">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Icon className="h-5 w-5" aria-hidden />
                </span>
                <h3 className="mt-4 font-semibold text-slate-900">{title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{text}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Featured projects */}
      <section className="mx-auto max-w-6xl px-4 pb-12">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900">Featured Projects</h2>
            <p className="mt-1 text-sm text-muted-foreground">The latest faculty-approved submissions, loaded live from the database.</p>
          </div>
          <Button variant="outline" onClick={() => navigate('/explore')}>View all projects</Button>
        </div>
        {loading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-xl border bg-white p-4">
                <Skeleton className="aspect-[16/10] w-full rounded-lg" />
                <Skeleton className="mt-4 h-5 w-3/4" />
                <Skeleton className="mt-2 h-4 w-full" />
                <Skeleton className="mt-2 h-4 w-2/3" />
              </div>
            ))}
          </div>
        ) : featured.length > 0 ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((p) => (
              <ProjectCard key={p.id} project={p} />
            ))}
          </div>
        ) : (
          <EmptyState
            icon={FolderOpen}
            title="No approved projects yet"
            description="Once faculty approve student submissions, they will appear here automatically."
          >
            <Button onClick={() => navigate('/register')}>Be the first to submit</Button>
          </EmptyState>
        )}
      </section>

      {/* Categories */}
      <section className="border-t bg-slate-50/70">
        <div className="mx-auto max-w-6xl px-4 py-12">
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Browse by Category</h2>
          <p className="mt-1 text-sm text-muted-foreground">Jump straight into the kind of project you are curious about.</p>
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => navigate(`/explore?category=${encodeURIComponent(c.name)}`)}
                className="rounded-xl border bg-white p-4 text-left transition hover:border-primary/40 hover:shadow-sm"
              >
                <div className="font-medium text-slate-900">{c.name}</div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {c.approvedCount} approved project{c.approvedCount === 1 ? '' : 's'}
                </div>
              </button>
            ))}
            {loading && [1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-4 pb-14 pt-12">
        <div className="rounded-2xl bg-primary px-6 py-10 text-center text-white md:px-12">
          <h2 className="text-2xl font-bold md:text-3xl">Ready to showcase your project?</h2>
          <p className="mx-auto mt-2 max-w-xl text-sm text-white/80">
            Create your student account, upload your mini project with a screenshot and GitHub link,
            and let faculty review it for the public showcase.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button className="bg-white text-primary hover:bg-white/90" onClick={submitProject}>
              Submit Your Project
            </Button>
            <Button
              variant="outline"
              className="border-white/40 bg-transparent text-white hover:bg-white/10 hover:text-white"
              onClick={() => navigate('/explore')}
            >
              Explore Projects
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
