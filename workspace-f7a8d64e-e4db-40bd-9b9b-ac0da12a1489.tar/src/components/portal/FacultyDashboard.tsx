'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import Image from 'next/image'
import {
  BarChart3,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Database,
  Github,
  ImageIcon,
  Loader2,
  Pencil,
  Plus,
  Search,
  Tags,
  Trash2,
  XCircle,
} from 'lucide-react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { api, ApiError } from '@/lib/api-client'
import { formatDate } from '@/components/portal/format'
import { EmptyState, StatCard, StatusBadge, TechChips } from '@/components/portal/ui-bits'
import type { CategoryInfo, Project, ProjectStatus, Stats } from '@/lib/types'

type StatusFilter = 'all' | ProjectStatus
const STATUS_FILTERS: StatusFilter[] = ['all', 'Pending', 'Approved', 'Rejected']

function Bar({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="w-44 shrink-0 truncate text-sm text-slate-700">{label}</span>
      <div className="h-2.5 flex-1 rounded-full bg-slate-100">
        <div
          className={`h-2.5 rounded-full transition-all ${color}`}
          style={{ width: `${max > 0 ? Math.round((value / max) * 100) : 0}%` }}
        />
      </div>
      <span className="w-8 text-right text-sm font-medium">{value}</span>
    </div>
  )
}

export function FacultyDashboard({ initialTab }: { initialTab?: string | null }) {
  const [tab, setTab] = useState(
    initialTab === 'categories' ? 'categories' : initialTab === 'analytics' ? 'analytics' : 'review'
  )
  const [projects, setProjects] = useState<Project[]>([])
  const [stats, setStats] = useState<Stats | null>(null)
  const [categories, setCategories] = useState<CategoryInfo[]>([])
  const [loading, setLoading] = useState(true)

  // Client-side filters for the review table.
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [batchFilter, setBatchFilter] = useState('all')
  const [q, setQ] = useState('')

  // Review dialog state.
  const [reviewTarget, setReviewTarget] = useState<Project | null>(null)
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject' | null>(null)
  const [confirmReject, setConfirmReject] = useState(false)

  // Category management state.
  const [newCategory, setNewCategory] = useState('')
  const [creatingCategory, setCreatingCategory] = useState(false)
  const [renameId, setRenameId] = useState<string | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const [renameSaving, setRenameSaving] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<CategoryInfo | null>(null)
  const [deleting, setDeleting] = useState(false)

  const load = useCallback(() => {
    Promise.all([
      api<{ projects: Project[] }>('/api/projects?scope=all'), // faculty token -> every project
      api<Stats>('/api/projects/stats'),
      api<{ categories: CategoryInfo[] }>('/api/categories'),
    ])
      .then(([p, s, c]) => {
        setProjects(p.projects)
        setStats(s)
        setCategories(c.categories)
      })
      .catch((e) => toast.error(e instanceof ApiError ? e.message : 'Could not load dashboard data.'))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const batches = useMemo(() => [...new Set(projects.map((p) => p.batch))].sort(), [projects])

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase()
    return projects.filter((p) => {
      if (statusFilter !== 'all' && p.status !== statusFilter) return false
      if (categoryFilter !== 'all' && p.category !== categoryFilter) return false
      if (batchFilter !== 'all' && p.batch !== batchFilter) return false
      if (
        needle &&
        !(
          p.title.toLowerCase().includes(needle) ||
          p.student.name.toLowerCase().includes(needle) ||
          p.description.toLowerCase().includes(needle)
        )
      ) {
        return false
      }
      return true
    })
  }, [projects, statusFilter, categoryFilter, batchFilter, q])

  const doStatus = async (project: Project, status: 'Approved' | 'Rejected') => {
    setReviewAction(status === 'Approved' ? 'approve' : 'reject')
    try {
      const res = await api<{ message: string }>(`/api/projects/status/${project.id}`, {
        method: 'PUT',
        body: { status },
      })
      toast.success(res.message)
      setReviewTarget(null)
      setConfirmReject(false)
      load()
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Could not update the status.')
    } finally {
      setReviewAction(null)
    }
  }

  const createCategory = async () => {
    const name = newCategory.trim()
    if (name.length < 2) return
    setCreatingCategory(true)
    try {
      const res = await api<{ message: string }>('/api/categories', { body: { name } })
      toast.success(res.message)
      setNewCategory('')
      load()
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Could not create the category.')
    } finally {
      setCreatingCategory(false)
    }
  }

  const saveRename = async (c: CategoryInfo) => {
    const name = renameValue.trim()
    if (name.length < 2) return
    setRenameSaving(true)
    try {
      const res = await api<{ message: string }>(`/api/categories/${c.id}`, { method: 'PUT', body: { name } })
      toast.success(res.message)
      setRenameId(null)
      load()
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Could not rename the category.')
    } finally {
      setRenameSaving(false)
    }
  }

  const confirmDeleteCategory = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await api<{ message: string }>(`/api/categories/${deleteTarget.id}`, { method: 'DELETE' })
      toast.success(res.message)
      setDeleteTarget(null)
      load()
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Could not delete the category.')
      setDeleteTarget(null)
    } finally {
      setDeleting(false)
    }
  }

  const statusCount = (s: Exclude<StatusFilter, 'all'>) =>
    s === 'Pending' ? stats?.pending : s === 'Approved' ? stats?.approved : stats?.rejected

  const maxCategory = stats ? Math.max(...stats.byCategory.map((g) => g.count), 1) : 1
  const maxBatch = stats ? Math.max(...stats.byBatch.map((g) => g.count), 1) : 1

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Faculty Dashboard</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Review submissions, manage categories and monitor project statistics.
        </p>
      </div>

      {loading && !stats ? (
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-20 w-full rounded-xl" />
          ))}
        </div>
      ) : (
        stats && (
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard icon={Database} label="Total Submitted" value={stats.total} tone="navy" />
            <StatCard icon={Clock} label="Pending Review" value={stats.pending} tone="amber" />
            <StatCard icon={CheckCircle2} label="Approved" value={stats.approved} tone="green" />
            <StatCard icon={XCircle} label="Rejected" value={stats.rejected} tone="red" />
          </div>
        )
      )}

      <Tabs value={tab} onValueChange={setTab} className="mt-8">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="review" className="gap-1.5">
            <ClipboardCheck className="h-4 w-4" aria-hidden /> Review
          </TabsTrigger>
          <TabsTrigger value="categories" className="gap-1.5">
            <Tags className="h-4 w-4" aria-hidden /> Categories
          </TabsTrigger>
          <TabsTrigger value="analytics" className="gap-1.5">
            <BarChart3 className="h-4 w-4" aria-hidden /> Analytics
          </TabsTrigger>
        </TabsList>

        {/* ---------------- Review queue ---------------- */}
        <TabsContent value="review" className="mt-4 space-y-4">
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filter by status">
              {STATUS_FILTERS.map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
                    statusFilter === s
                      ? 'bg-primary text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {s === 'all' ? 'All' : s}
                  {s !== 'all' && statusCount(s) !== undefined ? ` (${statusCount(s)})` : ''}
                </button>
              ))}
            </div>
            <div className="mt-3 grid gap-3 md:grid-cols-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search project or student..."
                  className="pl-9"
                  aria-label="Search projects or students"
                />
              </div>
              <div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger aria-label="Filter by category">
                    <SelectValue placeholder="All categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All categories</SelectItem>
                    {categories.map((c) => (
                      <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Select value={batchFilter} onValueChange={setBatchFilter}>
                  <SelectTrigger aria-label="Filter by batch">
                    <SelectValue placeholder="All batches" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All batches</SelectItem>
                    {batches.map((b) => (
                      <SelectItem key={b} value={b}>{b}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <p className="text-sm text-muted-foreground">
            Showing {filtered.length} of {projects.length} submission(s)
          </p>

          {/* Desktop table */}
          <div className="hidden overflow-x-auto rounded-xl border bg-white shadow-sm scrollbar-thin md:block">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Project Name</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Batch</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="max-w-[16rem]">
                      <div className="truncate font-medium text-slate-900">{p.title}</div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">{p.student.name}</TableCell>
                    <TableCell className="whitespace-nowrap">{p.category}</TableCell>
                    <TableCell className="whitespace-nowrap">{p.batch}</TableCell>
                    <TableCell className="whitespace-nowrap">{formatDate(p.createdAt)}</TableCell>
                    <TableCell>
                      <StatusBadge status={p.status} />
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant={p.status === 'Pending' ? 'default' : 'outline'}
                        onClick={() => setReviewTarget(p)}
                      >
                        {p.status === 'Pending' ? 'Review' : 'View'}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="py-10 text-center text-sm text-muted-foreground">
                      No submissions match the current filters.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          {/* Mobile cards */}
          <div className="space-y-3 md:hidden">
            {filtered.map((p) => (
              <Card key={p.id} className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="truncate font-medium text-slate-900">{p.title}</div>
                    <div className="mt-0.5 text-xs text-muted-foreground">
                      {p.student.name} &middot; {p.category} &middot; Batch {p.batch}
                    </div>
                    <div className="mt-0.5 text-xs text-muted-foreground">Submitted {formatDate(p.createdAt)}</div>
                  </div>
                  <StatusBadge status={p.status} />
                </div>
                <Button
                  size="sm"
                  variant={p.status === 'Pending' ? 'default' : 'outline'}
                  className="mt-3 w-full"
                  onClick={() => setReviewTarget(p)}
                >
                  {p.status === 'Pending' ? 'Review Project' : 'View Details'}
                </Button>
              </Card>
            ))}
            {filtered.length === 0 && (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No submissions match the current filters.
              </p>
            )}
          </div>
        </TabsContent>

        {/* ---------------- Category management ---------------- */}
        <TabsContent value="categories" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Project Categories</CardTitle>
              <p className="text-sm text-muted-foreground">
                These categories appear in the student submission form. Categories still used by projects
                cannot be deleted; renaming updates existing projects safely.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && createCategory()}
                  placeholder="New category name (e.g. Cybersecurity)"
                  aria-label="New category name"
                />
                <Button onClick={createCategory} disabled={creatingCategory || newCategory.trim().length < 2}>
                  {creatingCategory ? (
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                  ) : (
                    <Plus className="h-4 w-4" aria-hidden />
                  )}
                  Add
                </Button>
              </div>
              <div className="divide-y rounded-xl border">
                {categories.map((c) => (
                  <div key={c.id} className="flex items-center justify-between gap-3 px-4 py-3">
                    {renameId === c.id ? (
                      <div className="flex flex-1 items-center gap-2">
                        <Input
                          value={renameValue}
                          onChange={(e) => setRenameValue(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && saveRename(c)}
                          aria-label="Category name"
                          autoFocus
                        />
                        <Button size="sm" onClick={() => saveRename(c)} disabled={renameSaving || renameValue.trim().length < 2}>
                          {renameSaving ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : 'Save'}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setRenameId(null)}>
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <>
                        <div className="flex min-w-0 items-center gap-3">
                          <span className="truncate font-medium text-slate-900">{c.name}</span>
                          <Badge variant="secondary" className="shrink-0">
                            {c.projectCount} project{c.projectCount === 1 ? '' : 's'}
                          </Badge>
                        </div>
                        <div className="flex shrink-0 items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => {
                              setRenameId(c.id)
                              setRenameValue(c.name)
                            }}
                            aria-label={`Rename ${c.name}`}
                          >
                            <Pencil className="h-4 w-4" aria-hidden />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-red-600 hover:text-red-600"
                            onClick={() => setDeleteTarget(c)}
                            aria-label={`Delete ${c.name}`}
                          >
                            <Trash2 className="h-4 w-4" aria-hidden />
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
                {categories.length === 0 && (
                  <div className="px-4 py-8 text-center text-sm text-muted-foreground">
                    No categories yet. Add the first one above.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ---------------- Analytics ---------------- */}
        <TabsContent value="analytics" className="mt-4">
          {stats ? (
            <div className="grid gap-4 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Projects by Category</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {stats.byCategory.length > 0 ? (
                    stats.byCategory.map((g) => (
                      <Bar key={g.name} label={g.name} value={g.count} max={maxCategory} color="bg-primary" />
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No submissions yet.</p>
                  )}
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Projects by Batch</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {stats.byBatch.length > 0 ? (
                    stats.byBatch.map((g) => (
                      <Bar key={g.name} label={g.name} value={g.count} max={maxBatch} color="bg-teal-600" />
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No submissions yet.</p>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            <Skeleton className="h-64 w-full rounded-xl" />
          )}
          <p className="mt-3 text-xs text-muted-foreground">
            All statistics are calculated live from the database records.
          </p>
        </TabsContent>
      </Tabs>

      {/* ---------------- Review dialog ---------------- */}
      <Dialog
        open={!!reviewTarget}
        onOpenChange={(open) => {
          if (!open) {
            setReviewTarget(null)
            setConfirmReject(false)
          }
        }}
      >
        <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto scrollbar-thin">
          {reviewTarget && (
            <>
              <DialogHeader>
                <DialogTitle className="pr-6">{reviewTarget.title}</DialogTitle>
                <DialogDescription>
                  Submitted by {reviewTarget.student.name} on {formatDate(reviewTarget.createdAt)}
                </DialogDescription>
              </DialogHeader>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="overflow-hidden rounded-lg border bg-slate-50">
                  {reviewTarget.screenshotPath ? (
                    <Image
                      src={reviewTarget.screenshotPath}
                      alt={`${reviewTarget.title} screenshot`}
                      width={600}
                      height={340}
                      className="h-48 w-full object-cover"
                      unoptimized
                    />
                  ) : (
                    <div className="flex h-48 items-center justify-center">
                      <ImageIcon className="h-8 w-8 text-slate-300" aria-hidden />
                    </div>
                  )}
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-muted-foreground">Status</span>
                    <StatusBadge status={reviewTarget.status} />
                  </div>
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-muted-foreground">Category</span>
                    <span className="font-medium">{reviewTarget.category}</span>
                  </div>
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-muted-foreground">Batch</span>
                    <span className="font-medium">{reviewTarget.batch}</span>
                  </div>
                  <div className="flex items-start justify-between gap-3">
                    <span className="text-muted-foreground">Student</span>
                    <span className="text-right">
                      <span className="block font-medium">{reviewTarget.student.name}</span>
                      <span className="block text-xs text-muted-foreground">{reviewTarget.student.email}</span>
                    </span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Team Members</span>
                    <div className="mt-0.5 font-medium">{reviewTarget.teamMembers.join(', ')}</div>
                  </div>
                </div>
              </div>

              <div>
                <div className="text-sm font-medium">Technologies</div>
                <div className="mt-1.5">
                  <TechChips items={reviewTarget.technologies} max={99} />
                </div>
              </div>

              <div>
                <div className="text-sm font-medium">Description</div>
                <p className="mt-1 max-h-36 overflow-y-auto whitespace-pre-line rounded-lg border bg-slate-50 p-3 text-sm leading-relaxed text-slate-700 scrollbar-thin">
                  {reviewTarget.description}
                </p>
              </div>

              <a href={reviewTarget.githubLink} target="_blank" rel="noopener noreferrer" className="block">
                <Button variant="outline" className="w-full gap-2">
                  <Github className="h-4 w-4" aria-hidden /> Open GitHub Repository
                </Button>
              </a>

              <DialogFooter className="gap-2 sm:gap-2">
                <Button
                  variant="outline"
                  className="border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
                  disabled={reviewAction !== null}
                  onClick={() => setConfirmReject(true)}
                >
                  Reject
                </Button>
                <Button
                  className="bg-emerald-600 text-white hover:bg-emerald-700"
                  disabled={reviewAction !== null}
                  onClick={() => doStatus(reviewTarget, 'Approved')}
                >
                  {reviewAction === 'approve' && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
                  Approve Project
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Reject confirmation */}
      <AlertDialog open={confirmReject} onOpenChange={setConfirmReject}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reject this project?</AlertDialogTitle>
            <AlertDialogDescription>
              Rejected projects stay hidden from the public showcase. The student will see the updated
              status on their dashboard.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 text-white hover:bg-red-700"
              disabled={reviewAction !== null}
              onClick={(e) => {
                e.preventDefault()
                if (reviewTarget) doStatus(reviewTarget, 'Rejected')
              }}
            >
              {reviewAction === 'reject' && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
              Reject Project
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Category delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete &ldquo;{deleteTarget?.name}&rdquo;?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget && deleteTarget.projectCount > 0
                ? `This category is used by ${deleteTarget.projectCount} project(s). It cannot be deleted until those projects are re-assigned.`
                : 'This will permanently remove the category from the submission form.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 text-white hover:bg-red-700"
              disabled={deleting || (deleteTarget?.projectCount ?? 0) > 0}
              onClick={(e) => {
                e.preventDefault()
                confirmDeleteCategory()
              }}
            >
              {deleting ? 'Deleting…' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
