'use client'

import type { LucideIcon } from 'lucide-react'
import type { ProjectStatus } from '@/lib/types'

const STATUS_STYLES: Record<ProjectStatus, string> = {
  Pending: 'bg-amber-100 text-amber-800 border border-amber-300',
  Approved: 'bg-emerald-100 text-emerald-800 border border-emerald-300',
  Rejected: 'bg-red-100 text-red-700 border border-red-300',
}

const STATUS_DOT: Record<ProjectStatus, string> = {
  Pending: 'bg-amber-500',
  Approved: 'bg-emerald-600',
  Rejected: 'bg-red-500',
}

export function StatusBadge({ status, className = '' }: { status: ProjectStatus; className?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium ${STATUS_STYLES[status]} ${className}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[status]}`} aria-hidden />
      {status}
    </span>
  )
}

export function TechChips({ items, max = 4 }: { items: string[]; max?: number }) {
  const shown = items.slice(0, max)
  const rest = items.length - shown.length
  return (
    <div className="flex flex-wrap gap-1">
      {shown.map((t) => (
        <span key={t} className="rounded-md bg-slate-100 px-2 py-0.5 text-xs text-slate-700">
          {t}
        </span>
      ))}
      {rest > 0 && (
        <span className="rounded-md bg-slate-100 px-2 py-0.5 text-xs text-slate-500">+{rest} more</span>
      )}
    </div>
  )
}

const STAT_TONES = {
  navy: 'bg-primary/10 text-primary',
  teal: 'bg-teal-50 text-teal-700',
  amber: 'bg-amber-50 text-amber-700',
  green: 'bg-emerald-50 text-emerald-700',
  red: 'bg-red-50 text-red-600',
} as const

export function StatCard({
  icon: Icon,
  label,
  value,
  tone = 'navy',
}: {
  icon: LucideIcon
  label: string
  value: number | string
  tone?: keyof typeof STAT_TONES
}) {
  return (
    <div className="flex items-center gap-3 rounded-xl border bg-white p-4 shadow-sm">
      <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${STAT_TONES[tone]}`}>
        <Icon className="h-5 w-5" aria-hidden />
      </div>
      <div className="min-w-0">
        <div className="text-2xl font-semibold leading-none">{value}</div>
        <div className="mt-1 truncate text-sm text-muted-foreground">{label}</div>
      </div>
    </div>
  )
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: LucideIcon
  title: string
  description: string
  children?: React.ReactNode
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed bg-white px-6 py-14 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-100">
        <Icon className="h-6 w-6 text-slate-400" aria-hidden />
      </div>
      <h3 className="mt-4 text-base font-semibold">{title}</h3>
      <p className="mt-1 max-w-md text-sm text-muted-foreground">{description}</p>
      {children && <div className="mt-4">{children}</div>}
    </div>
  )
}
