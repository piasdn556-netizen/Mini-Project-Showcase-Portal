'use client'

import { GraduationCap } from 'lucide-react'
import { useAuth } from '@/lib/store'
import { navigate } from '@/lib/router'

export function Footer() {
  const user = useAuth((s) => s.user)
  const year = new Date().getFullYear()

  const link = 'text-sm text-slate-600 transition-colors hover:text-primary'

  return (
    <footer className="mt-auto border-t bg-white pb-[calc(0.25rem+env(safe-area-inset-bottom))]">
      <div className="mx-auto max-w-6xl px-4 py-10">
        <div className="grid gap-8 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
                <GraduationCap className="h-5 w-5 text-white" aria-hidden />
              </span>
              <span className="text-sm font-bold text-slate-900">Mini Project Showcase Portal</span>
            </div>
            <p className="mt-3 max-w-xs text-sm text-muted-foreground">
              Discover. Showcase. Innovate. A centralized platform where student mini projects are
              submitted, reviewed by faculty, and celebrated.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-900">Quick Links</h3>
            <div className="mt-3 flex flex-col gap-2">
              <button className={`${link} text-left`} onClick={() => navigate('/')}>Home</button>
              <button className={`${link} text-left`} onClick={() => navigate('/explore')}>Explore Projects</button>
              {user ? (
                <button
                  className={`${link} text-left`}
                  onClick={() => navigate(user.role === 'faculty' ? '/faculty' : '/dashboard')}
                >
                  {user.role === 'faculty' ? 'Faculty Dashboard' : 'My Dashboard'}
                </button>
              ) : (
                <button className={`${link} text-left`} onClick={() => navigate('/login')}>Login / Register</button>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-900">Roles</h3>
            <div className="mt-3 flex flex-col gap-2">
              <button className={`${link} text-left`} onClick={() => navigate(user?.role === 'student' ? '/add-project' : '/register')}>
                Students &mdash; submit &amp; track projects
              </button>
              <button className={`${link} text-left`} onClick={() => navigate(user?.role === 'faculty' ? '/faculty' : '/login')}>
                Faculty &mdash; review &amp; approve
              </button>
              <button className={`${link} text-left`} onClick={() => navigate('/explore')}>
                Visitors &mdash; browse approved work
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-col gap-2 border-t pt-4 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <span>&copy; {year} Mini Project Showcase Portal &middot; College Hackathon Project</span>
          <span>Secured with JWT authentication &middot; bcrypt password hashing</span>
        </div>
      </div>
    </footer>
  )
}
