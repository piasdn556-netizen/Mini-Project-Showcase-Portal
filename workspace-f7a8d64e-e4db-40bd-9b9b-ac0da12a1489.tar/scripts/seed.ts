/**
 * Seed script - inserts realistic demo data for the hackathon presentation.
 * Run with: bun run seed
 * WARNING: resets all Users, Projects and Categories before inserting.
 */
import { PrismaClient } from '@prisma/client'
import { hash } from 'bcryptjs'

const db = new PrismaClient()

const CATEGORIES = ['Web Development', 'Mobile Applications', 'Artificial Intelligence', 'IoT', 'Other']

const daysAgo = (n: number) => new Date(Date.now() - n * 24 * 60 * 60 * 1000)

async function main() {
  console.log('Resetting demo data...')
  await db.project.deleteMany()
  await db.category.deleteMany()
  await db.user.deleteMany()

  console.log('Creating categories...')
  for (const name of CATEGORIES) {
    await db.category.create({ data: { name } })
  }

  console.log('Creating demo users...')
  const facultyPassword = await hash('Faculty@123', 10)
  const studentPassword = await hash('Student@123', 10)

  const faculty = await db.user.create({
    data: { name: 'Dr. Meera Krishnan', email: 'faculty@college.edu', password: facultyPassword, role: 'faculty' },
  })
  const aarav = await db.user.create({
    data: { name: 'Aarav Sharma', email: 'aarav@college.edu', password: studentPassword, role: 'student' },
  })
  const priya = await db.user.create({
    data: { name: 'Priya Nair', email: 'priya@college.edu', password: studentPassword, role: 'student' },
  })
  const rohan = await db.user.create({
    data: { name: 'Rohan Gupta', email: 'rohan@college.edu', password: studentPassword, role: 'student' },
  })

  console.log('Creating demo projects...')
  await db.project.createMany({
    data: [
      {
        title: 'AI-Powered Cattle Breed Recognition',
        description:
          'A computer vision web application that identifies Indian cattle breeds from uploaded images using a convolutional neural network. The trained model recognizes 12 native breeds with 92% top-1 accuracy, helping dairy farmers maintain accurate livestock records without manual paperwork.',
        technologies: 'Python, TensorFlow, OpenCV, Flask',
        teamMembers: 'Aarav Sharma, Kavya Iyer, Dev Patel',
        githubLink: 'https://github.com/aarav-sharma/cattle-breed-recognition',
        screenshotPath: '/seed/cattle.png',
        category: 'Artificial Intelligence',
        batch: '2022-2026',
        studentId: aarav.id,
        status: 'Approved',
        createdAt: daysAgo(30),
        reviewedAt: daysAgo(25),
      },
      {
        title: 'Student Performance Analytics',
        description:
          'An analytics dashboard that helps faculty understand student marks across semesters with interactive charts, subject-wise trend lines and automatically generated topper and at-risk lists. Reports can be exported as CSV for department meetings.',
        technologies: 'React, Node.js, Chart.js, MySQL',
        teamMembers: 'Priya Nair, Aditi Rao',
        githubLink: 'https://github.com/priya-nair/student-performance-analytics',
        screenshotPath: '/seed/analytics.png',
        category: 'Web Development',
        batch: '2023-2027',
        studentId: priya.id,
        status: 'Approved',
        createdAt: daysAgo(22),
        reviewedAt: daysAgo(18),
      },
      {
        title: 'IoT Smart Irrigation System',
        description:
          'An automated drip irrigation controller that reads soil moisture, temperature and humidity sensors and waters crops only when required. Sensor readings are published over MQTT and visualized on a live web dashboard, cutting water usage by roughly 40% during field testing.',
        technologies: 'Arduino, ESP32, MQTT, C++',
        teamMembers: 'Rohan Gupta, Sneha Kulkarni',
        githubLink: 'https://github.com/rohan-gupta/smart-irrigation',
        screenshotPath: '/seed/irrigation.png',
        category: 'IoT',
        batch: '2022-2026',
        studentId: rohan.id,
        status: 'Approved',
        createdAt: daysAgo(12),
        reviewedAt: daysAgo(9),
      },
      {
        title: 'Credit Card Fraud Detection',
        description:
          'A machine learning pipeline that flags potentially fraudulent card transactions in real time using a Random Forest classifier balanced with SMOTE. A Streamlit app lets reviewers upload transaction batches and inspect risk scores with feature explanations.',
        technologies: 'Python, scikit-learn, Pandas, Streamlit',
        teamMembers: 'Aarav Sharma, Farhan Ali',
        githubLink: 'https://github.com/aarav-sharma/fraud-detection',
        screenshotPath: '/seed/fraud.png',
        category: 'Artificial Intelligence',
        batch: '2023-2027',
        studentId: aarav.id,
        status: 'Pending',
        createdAt: daysAgo(8),
      },
      {
        title: 'Smart Attendance System',
        description:
          'A cross-platform mobile app that marks classroom attendance using on-device face recognition with GPS-verified check-ins, so proxies become impossible.',
        technologies: 'Flutter, Firebase, ML Kit',
        teamMembers: 'Priya Nair, Nikhil Verma',
        githubLink: 'https://github.com/priya-nair/smart-attendance',
        screenshotPath: '/seed/attendance.png',
        category: 'Mobile Applications',
        batch: '2023-2027',
        studentId: priya.id,
        status: 'Rejected',
        createdAt: daysAgo(5),
        reviewedAt: daysAgo(3),
      },
      {
        title: 'Library Seat Booking System',
        description:
          'A web portal where students reserve reading-hall seats in advance, complete with a live seat map, QR-code check-in and automatic release of unclaimed bookings after 20 minutes.',
        technologies: 'JavaScript, Express.js, SQLite, Bootstrap',
        teamMembers: 'Rohan Gupta, Isha Saxena, Manav Joshi',
        githubLink: 'https://github.com/rohan-gupta/library-seat-booking',
        screenshotPath: '/seed/library.png',
        category: 'Web Development',
        batch: '2024-2028',
        studentId: rohan.id,
        status: 'Approved',
        createdAt: daysAgo(2),
        reviewedAt: daysAgo(1),
      },
    ],
  })

  console.log('\nSeed complete! Demo credentials:')
  console.log('  Faculty  : faculty@college.edu / Faculty@123')
  console.log('  Student  : aarav@college.edu  / Student@123')
  console.log('  Student  : priya@college.edu  / Student@123')
  console.log('  Student  : rohan@college.edu  / Student@123')
  console.log(`  Faculty user id: ${faculty.id}`)
}

main()
  .catch((e) => {
    console.error('Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
