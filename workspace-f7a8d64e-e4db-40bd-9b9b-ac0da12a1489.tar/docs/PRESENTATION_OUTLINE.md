# Presentation Outline - Mini Project Showcase Portal

Tagline: **Discover. Showcase. Innovate.**

10-slide deck for the hackathon presentation. Each slide lists the talking-point bullets and a speaker hint describing what to say or show on screen. Target duration: 8-10 minutes.

---

## Slide 1 - Project Title & Team

**Bullets**
- Mini Project Showcase Portal - Discover. Showcase. Innovate.
- One moderated home for every student mini project in the college.
- Team name, member names, batch and guide (fill in before presenting).
- Role split: backend/API, frontend/UI, database, demo prep.

**Speaker hint:** Open on the portal home page behind the title slide. Introduce the team in one sentence each and state the one-line pitch: "a faculty-approved showcase of student work."

---

## Slide 2 - Problem Statement

**Bullets**
- Project details are scattered across WhatsApp groups, email and personal drives.
- No approval mechanism - faculty cannot verify what gets published in the department's name.
- No discovery - juniors cannot find what seniors already built by technology, category or batch.
- No central showcase for visitors, recruiters and accreditation evidence.

**Speaker hint:** Tell a short real story: "when a recruiter asked for our best projects last year, it took two days to collect links." Keep it to 60-90 seconds.

---

## Slide 3 - Proposed Solution

**Bullets**
- A single web portal where students submit projects with title, description, tech stack, team, GitHub link and screenshot.
- Faculty review queue: every submission starts as Pending and is approved or rejected by faculty.
- Approved projects become instantly public on Home and Explore; rejected ones stay private.
- Search and filters (keyword, technology, category, batch) plus live analytics for faculty.

**Speaker hint:** Show the 10-second mental model: Student submits -> Faculty approves -> World discovers. Point at the three roles in the header/footer of the app.

---

## Slide 4 - Objectives & Features

**Bullets**
- Objective 1: structured submission with validated multipart form + screenshot upload.
- Objective 2: faculty moderation with approve/reject and audit timestamp (reviewedAt).
- Objective 3: public discovery - search, category pages, batch and technology filters.
- Objective 4: category management and live analytics computed from the database.
- Student safeguards: edit/delete only while Pending; rejected projects stay hidden.

**Speaker hint:** Walk the three columns quickly: Public Visitor, Student, Faculty - one feature sentence each. Mention the seed data shows all three statuses at once.

---

## Slide 5 - Technology Stack

**Bullets**
- Backend: REST API routes (Next.js App Router Route Handlers) - same REST shape as the Express spec.
- Database: SQLite with Prisma ORM - the three collections (User, Project, Category) map 1:1 from the MongoDB/Mongoose design.
- Uploads: multipart FormData handling with type/size validation and safe filenames - replaces Multer.
- Auth: JWT (7-day, Bearer header) + bcrypt password hashing + role middleware.
- Frontend: React single-page app with hash routing, Tailwind CSS + shadcn/ui, TypeScript.

**Speaker hint:** Be upfront and confident: "we built in our sandbox stack, function-for-function identical to the Express + MongoDB spec - here is the exact mapping" and show the README mapping table for two lines only.

---

## Slide 6 - System Architecture

**Bullets**
- Browser SPA (React, hash routes) -> JSON REST API -> Prisma ORM -> SQLite file.
- API layer enforces JWT auth, role checks, ownership checks and validation on every request.
- Upload pipeline: multipart form -> validation (JPG/PNG/WebP, 5 MB) -> `uploads/` with random safe filename -> served by `/api/uploads/:name`.
- All views live under one page (`/`); protected views are guarded by role on both client and server.

**Speaker hint:** Draw the 4-box diagram live or show it pre-drawn: Client -> API -> Prisma -> DB, with the uploads folder on the side. Emphasize that authorization is server-side, not just hidden buttons.

---

## Slide 7 - Database Design

**Bullets**
- User: id, name, email (unique), bcrypt password hash, role (student/faculty), timestamps.
- Project: title, description, technologies, teamMembers, githubLink, screenshotPath, category, batch, studentId (FK, cascade), status (Pending/Approved/Rejected), reviewedAt, timestamps.
- Category: unique name; projects reference it and are safely re-assigned on rename.
- Indexes on status, studentId, category and batch - one for each list/filter/stats query.

**Speaker hint:** Show `prisma/schema.prisma` for 20 seconds. Highlight the status field as the heart of the workflow and the indexes as deliberate performance decisions.

---

## Slide 8 - Project Submission & Approval Workflow

**Bullets**
- 1) Student registers/logs in -> 2) submits project with screenshot.
- 3) Stored in the database with status Pending (status is never client-controlled).
- 4) Faculty opens the review queue -> 5) reviews details -> 6) approves or rejects (reject needs confirmation).
- 7) Approved projects appear publicly on Home/Explore immediately; rejected stay hidden (404 to outsiders).
- 8) Student dashboard reflects the decision; pending projects remain editable by the owner.

**Speaker hint:** This is the spec's 8-step lifecycle - read the numbered flow straight across the slide and promise the live demo next.

---

## Slide 9 - Live Demonstration / Screenshots

**Checklist (tick off during the demo)**
- Home page with live approved-project stats.
- Student: login -> submit "Campus Lost & Found" with screenshot upload.
- Student dashboard shows the new project as Pending; logout.
- Faculty: login -> review queue -> open review dialog -> Approve.
- Explore: approved project now public - use search and category filter.
- Reject the seeded Pending project (Credit Card Fraud Detection); show the student dashboard status change.
- Faculty analytics bars and category management (create/rename).

**Speaker hint:** Follow `docs/DEMO_VIDEO_SCRIPT.md` if the network fails - the recorded video is the backup. Keep the browser at 100% zoom, pre-logged-out, seeded.

---

## Slide 10 - Conclusion & Future Scope

**Bullets**
- Delivered: submission -> approval -> public showcase -> discovery -> analytics, end-to-end and working.
- Security-first: bcrypt, JWT, role and ownership checks, validated uploads, hidden rejected projects.
- Future: email notifications on review decisions, student comments/likes on projects, PDF export of the showcase, deployment on college servers, bulk CSV import of batches.
- Vision: become the department's permanent, searchable project archive.

**Speaker hint:** Close with impact: "every project a student builds this year will be findable in ten seconds." Thank the jury and invite questions.

---

## One-Minute Quick Pitch

"Colleges produce hundreds of mini projects, but the record of them is scattered across chat groups and never verified or discoverable. The Mini Project Showcase Portal fixes that with one moderated flow: students register and submit their project with a screenshot and GitHub link; the submission is stored as Pending; faculty review it in a queue and either approve or reject it; approved projects instantly become public on Explore where anyone can search by keyword, technology, category or batch; and faculty get live analytics plus category management. It runs on a REST API with JWT + bcrypt authentication, role-based access, validated file uploads and a three-model database - User, Project and Category - and the student dashboard always reflects the latest review decision. Discover. Showcase. Innovate."
