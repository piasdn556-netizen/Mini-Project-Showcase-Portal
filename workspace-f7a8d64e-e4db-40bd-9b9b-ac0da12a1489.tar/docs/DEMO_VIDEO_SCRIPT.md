# Demo Video Script - Mini Project Showcase Portal

Screen recording, 2-3 minutes, 1080p, following the real application flow.
Narration lines are written to be spoken as-is; keep sentences short and natural.

---

## Pre-Recording Checklist

- [ ] Run `npm run db:push` once, then `npm run seed` immediately before recording (resets demo data and timestamps).
- [ ] Verify the app is running on http://localhost:3000 (`npm run dev`).
- [ ] Demo accounts ready: `faculty@college.edu / Faculty@123` and `aarav@college.edu / Student@123`.
- [ ] Browser window at 1920x1080 (or at least 1280x720 at 16:9), zoom 100%, bookmarks bar hidden.
- [ ] No other tabs open; notifications silenced; clear the uploads/db only via seed, not manually.
- [ ] Practice the flow once so clicks stay ahead of the narration.

---

## Script

### 0:00 - 0:20 | Intro
**Narration:** "This is the Mini Project Showcase Portal - Discover, Showcase, Innovate. Students submit their mini projects, faculty review and approve them, and every approved project becomes publicly discoverable. Let me walk you through the full flow."

**On-screen:** Home page loaded at http://localhost:3000. Slow scroll over the hero, the live stats (approved projects, categories) and the latest approved projects. Land back at the top.

---

### 0:20 - 0:40 | Home page and public showcase
**Narration:** "Visitors need no account. The home page shows live counts from the database, and Explore lists only faculty-approved projects, with search and filters by technology, category and batch."

**On-screen:** Click "Explore" in the header. Show the project grid, then type a keyword in the search box (e.g. "IoT" or "attendance") and clear it. Optionally open one approved project's detail page and go back.

---

### 0:40 - 1:05 | Student login and project submission
**Narration:** "Now the student side. I'll log in as Aarav, a student, and submit a new project. The form validates every field and requires a screenshot up to five megabytes."

**On-screen:** Click Login, sign in as `aarav@college.edu / Student@123`. Click "Add Project". Fill the form: title "Campus Lost & Found Portal", a one-line description plus a sentence, technologies "React, Node.js", team members "Aarav Sharma, Meera Iyer", GitHub link `https://github.com/aarav-sharma/lost-and-found`, category "Web Development", batch "2023-2027". Choose a local image file as the screenshot. Click Submit and let the success toast appear.

---

### 1:05 - 1:25 | Pending status and student dashboard
**Narration:** "The submission is stored with status Pending - students can never set their own approval status. From the dashboard, the student can edit or delete it, but only while it is still pending."

**On-screen:** Open the student dashboard. Point at the stat cards (Total / Pending / Approved / Rejected) and the new project with its Pending badge. Hover the Edit and Delete buttons on the pending row. Click Logout in the header.

---

### 1:25 - 1:55 | Faculty review and approval
**Narration:** "Faculty logs in and sees the review queue - oldest submissions first. There are two pending now: my new submission and the seeded Credit Card Fraud Detection project. I'll open the review dialog and approve the new one."

**On-screen:** Login as `faculty@college.edu / Faculty@123`. The Faculty Dashboard opens on the Review tab. Click the new project row to open the review dialog - show the screenshot and details. Click "Approve Project" and let the success toast play. Return to the queue, where Credit Card Fraud Detection is still pending.

---

### 1:55 - 2:20 | Public visibility, then a rejection
**Narration:** "Approved means public instantly. On Explore, the new project is already searchable. For contrast, I'll reject the fraud detection project - rejected projects stay hidden from the public showcase."

**On-screen:** Open Explore, search "Lost" to show the approved project appears. Back to the faculty dashboard, open the review dialog for Credit Card Fraud Detection, click "Reject Project", confirm in the dialog, and note the toast says it stays hidden.

---

### 2:20 - 2:40 | Student sees the decision; faculty analytics
**Narration:** "The student dashboard reflects both decisions immediately: the new project is Approved, the other one shows Rejected. Faculty also get live analytics and category management."

**On-screen:** Logout, login as `aarav@college.edu / Student@123`, show the updated dashboard statuses. Logout, login as faculty again, open the Analytics tab (status cards plus Projects by Category and Projects by Batch bars), then the Categories tab - rename one category and show the toast reporting how many projects were re-assigned.

---

### 2:40 - 3:00 | Closing
**Narration:** "That is the complete lifecycle: submission, moderation, public discovery and analytics - secured with JWT authentication, bcrypt hashing, role-based access and validated uploads. Discover. Showcase. Innovate. Thank you for watching."

**On-screen:** End on the Home page hero with the tagline visible. Fade out or cut.

---

## Recording Tips

- Keep each click still for about a second before moving on so viewers can follow.
- If a toast disappears too fast, repeat the action rather than editing the video.
- If anything breaks, re-run `npm run seed`, reload, and record that segment again - the seed restores the exact demo state.
